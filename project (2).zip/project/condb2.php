<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookshop";


$conn = new mysqli($servername, $username, $password);

// เช็คการเชื่อมต่อ
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
