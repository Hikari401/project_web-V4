<?php
require_once __DIR__ . '/../condb.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

$pdo = new PDO(
    "mysql:host=localhost;dbname=bookshop;charset=utf8mb4",
    "root",
    "",
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

// เพิ่มความยาวสูงสุดของ GROUP_CONCAT (กันรายชื่อยาวถูกตัด)
$pdo->exec("SET SESSION group_concat_max_len = 4096");

/* ====== ✅ กดปุ่มยืนยัน ====== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_id'])) {
    $orderNumber = $_POST['confirm_id'];

    // หา uid ของ payment ผ่าน order_number
    $stmt_uid = $pdo->prepare("SELECT uid FROM payment WHERE order_number=?");
    $stmt_uid->execute([$orderNumber]);
    $uid = $stmt_uid->fetchColumn();

    if ($uid) {
        // ดึงรายการ order_details ที่รอการยืนยัน
        $stmt_orders = $pdo->prepare("SELECT bid, quantity FROM order_details WHERE order_number = ? AND status='pending'");
        $stmt_orders->execute([$orderNumber]);
        $orders = $stmt_orders->fetchAll(PDO::FETCH_ASSOC);

        try {
            $pdo->beginTransaction();

            foreach ($orders as $order) {
                $bid = $order['bid'];
                $qty = $order['quantity'];

                // ตรวจสอบ stock ก่อน
                $check_stock = $pdo->prepare("SELECT stock FROM book WHERE bid=?");
                $check_stock->execute([$bid]);
                $stock = $check_stock->fetchColumn();

                if ($stock < $qty) {
                    throw new Exception("❌ สต็อกของหนังสือรหัส $bid ไม่เพียงพอ (คงเหลือ $stock ต้องการ $qty)");
                }

                // ลด stock
                $update_stock = $pdo->prepare("UPDATE book SET stock = stock - ? WHERE bid=?");
                $update_stock->execute([$qty, $bid]);
            }

            // อัปเดตสถานะ order_details
            $stmt_confirm = $pdo->prepare("UPDATE order_details SET status='confirmed' WHERE order_number = ? AND status='pending'");
            $stmt_confirm->execute([$orderNumber]);

            // ✅ ลบ payment โดยใช้ order_number
            $stmt_del = $pdo->prepare("DELETE FROM payment WHERE order_number = ?");
            $stmt_del->execute([$orderNumber]);

            $pdo->commit();
            echo "<script>alert('✅ ยืนยันการชำระเงินและลด stock แล้ว'); window.location.href='" . $_SERVER['PHP_SELF'] . "';</script>";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "<script>alert('❌ ข้อผิดพลาด: " . $e->getMessage() . "');</script>";
        }
    }
}

/* ====== ❌ กดปุ่มปฏิเสธ ====== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reject_id'])) {
    $orderNumber = $_POST['reject_id'];

    // หา uid ของ payment
    $stmt_uid = $pdo->prepare("SELECT uid FROM payment WHERE order_number=?");
    $stmt_uid->execute([$orderNumber]);
    $uid = $stmt_uid->fetchColumn();

    if ($uid) {
        $stmt_orders = $pdo->prepare("SELECT bid, quantity FROM order_details WHERE order_number = ? AND status = 'pending'");
        $stmt_orders->execute([$orderNumber]);
        $orders = $stmt_orders->fetchAll(PDO::FETCH_ASSOC);

        try {
            $pdo->beginTransaction();

            // (Optional) คืน stock
            /*
            foreach ($orders as $order) {
                $bid = $order['bid'];
                $qty = $order['quantity'];
                $stmt_update = $pdo->prepare("UPDATE book SET stock = stock + ? WHERE bid=?");
                $stmt_update->execute([$qty, $bid]);
            }
            */

            // อัปเดตเป็น rejected
            $stmt_reject = $pdo->prepare("UPDATE order_details SET status='rejected' WHERE order_number = ? AND status='pending'");
            $stmt_reject->execute([$orderNumber]);

            // ✅ ลบ payment โดยใช้ order_number
            $stmt_del = $pdo->prepare("DELETE FROM payment WHERE order_number = ?");
            $stmt_del->execute([$orderNumber]);

            $pdo->commit();
            echo "<script>alert('❌ ปฏิเสธการชำระเงินแล้ว'); window.location.href='" . $_SERVER['PHP_SELF'] . "';</script>";
        } catch (Exception $e) {
            $pdo->rollBack();
            echo "<script>alert('❌ ข้อผิดพลาด: " . $e->getMessage() . "');</script>";
        }
    }
}


/* ====== 📥 ดึงรายการที่รอยืนยัน (รวมชื่อหนังสือทั้งหมดในแถวเดียว) ====== */
$sql = "
   SELECT
    p.pid,
    p.order_number,   
    p.uid,
    p.amount,
    p.method,
    p.slip,
    p.pay_date,
    u.name,
    u.email,
    COALESCE(
        GROUP_CONCAT(CONCAT(b.title, ' × ', od.quantity) ORDER BY b.title SEPARATOR ', '),
        '-'
    ) AS books
FROM payment p
LEFT JOIN user u
    ON p.uid = u.uid
LEFT JOIN order_details od
    ON p.order_number = od.order_number AND od.status = 'pending' 
LEFT JOIN book b
    ON od.bid = b.bid
WHERE p.status = 'pending'
GROUP BY
    p.pid, p.order_number, p.uid, p.amount, p.method, p.slip, p.pay_date, u.name, u.email
ORDER BY p.pay_date
";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>จัดการการชำระเงิน</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
<div class="container">
  <h3>📑 รายการแจ้งชำระ (Pending)</h3>
  <table class="table table-bordered align-middle">
    <thead class="table-light">
      <tr>
        <th>ID</th>
        <th>User</th>
        <th>Book(s)</th>
        <th>Amount</th>
        <th>Method</th>
        <th>Slip</th>
        <th>Pay Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($rows as $r): ?>
      <tr>
        <td><?= htmlspecialchars($r['pid']) ?></td>
        <td><?= htmlspecialchars($r['name'] ?? 'Unknown') ?> (<?= htmlspecialchars($r['email'] ?? '-') ?>)</td>
        <td><?= htmlspecialchars($r['books']) ?></td>
        <td><?= number_format((float)$r['amount'], 2) ?></td>
        <td><?= htmlspecialchars($r['method']) ?></td>
        <td>
          <?php if (!empty($r['slip'])): ?>
            <a href="../page_user/pay/uploads/<?= urlencode($r['slip']) ?>" target="_blank">ดูสลิป</a>
          <?php endif; ?>
        </td>
        <td><?= htmlspecialchars($r['pay_date']) ?></td>
        <td>
  <form method="post" style="display:inline">
    <input type="hidden" name="confirm_id" value="<?= htmlspecialchars($r['order_number']) ?>"> 
    <button class="btn btn-success btn-sm" type="submit">✅ ยืนยัน</button>
  </form>
  <form method="post" style="display:inline" onsubmit="return confirm('คุณแน่ใจหรือไม่ที่จะปฏิเสธ?')">
    <input type="hidden" name="reject_id" value="<?= htmlspecialchars($r['order_number']) ?>"> 
    <button class="btn btn-danger btn-sm" type="submit">❌ ปฏิเสธ</button>
  </form>
</td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <a href="admin-page.php">[ ย้อนกลับ ]</a>
</div>
</body>
</html>
