<?php
require_once __DIR__ . '/../condb.php';  // เชื่อมต่อ DB

// ดึงข้อมูลยอดขายรวมต่อหนังสือ (title, จำนวน, รวมราคา)
$sql = "
SELECT b.title, 
       SUM(od.quantity) AS total_qty, 
       SUM(od.quantity * od.price) AS total_sales
FROM order_details od
JOIN book b ON od.bid = b.bid
WHERE od.status != 'rejected'
GROUP BY b.bid
ORDER BY total_sales DESC
";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>รายงานยอดขายหนังสือ</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
  @media print {
    .no-print { display: none; }
  }
</style>
</head>
<body class="container mt-4">

<h2 class="mb-4">รายงานยอดขายหนังสือ</h2>

<table class="table table-bordered">
  <thead>
    <tr>
      <th>ชื่อหนังสือ</th>
      <th>จำนวนที่ขายได้</th>
      <th>ยอดขายรวม (บาท)</th>
    </tr>
  </thead>
  <tbody>
    <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
            echo "<td class='text-end'>" . number_format($row['total_qty']) . "</td>";
            echo "<td class='text-end'>" . number_format($row['total_sales'], 2) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3' class='text-center'>ไม่มีข้อมูล</td></tr>";
    }
    ?>
  </tbody>
</table>

<div class="no-print text-center mt-4">
  <button class="btn btn-primary" onclick="window.print()">พิมพ์รายงาน</button>
</div>

</body>
</html>
