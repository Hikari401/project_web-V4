<?php 
require_once __DIR__ . '/../condb.php'; // เชื่อมต่อฐานข้อมูล

// ตรวจสอบการส่งข้อมูลจากฟอร์ม
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // เลือกฐานข้อมูล bookshop
    if ($conn->select_db("bookshop") === true) {

        // รับค่าจากฟอร์ม
        $name     = htmlspecialchars($_POST['name']);
        $surname  = htmlspecialchars($_POST['surname']);
        $username = htmlspecialchars($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $email    = htmlspecialchars($_POST['email']);
        $tel      = htmlspecialchars($_POST['tel']);
        $address  = htmlspecialchars($_POST['address']);
        $role     = htmlspecialchars($_POST['role']);

        $sql_check = "SELECT * FROM user WHERE username = ?";
        $stmt_check = $conn->prepare($sql_check);
        $stmt_check->bind_param("s", $username);
        $stmt_check->execute();
        $result = $stmt_check->get_result();

        if ($result->num_rows > 0) {
            echo "<center>❌ มี username นี้ในระบบแล้ว</center>";
            echo "<center><a href='Register.php'>[กลับไปหน้าสมัครสมาชิก]</a></center>";
            exit();
        }

        $stmt = $conn->prepare("
            INSERT INTO User (name, surname, username, password, email, tel, address, role)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("ssssssss", $name, $surname, $username, $password, $email, $tel, $address, $role);

        if ($stmt->execute()) {
            echo "<center>✅ สมัครสมาชิกเรียบร้อยแล้ว</center>";
            $stmt->close();
            header("Location: Login.php");
            exit();
        } else {
            echo "<center>❌ เกิดข้อผิดพลาด: " . $stmt->error . "</center>";
        }

    } else {
        echo "<center>❌ ไม่สามารถเชื่อมต่อฐานข้อมูลได้</center>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>

  <style>
    /* กันบวมจาก padding/margin ทุกตัว */
*, *::before, *::after { box-sizing: border-box; }

/* กันสกรอลแนวนอนและรีเซ็ต margin/padding */
html, body {
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

/* ใช้ min-height แทน 100vh เพื่อไม่ให้ชนกรอบในบางบราวเซอร์/iframe */
body {
  /* พื้นหลังไล่สีเต็มหน้าจอ แต่ไม่ดันออกนอกกรอบ */
  background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%);
  font-family: "Prompt", sans-serif;
  min-height: 100dvh;     /* << เปลี่ยนจาก 100vh */
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;          /* มีขอบเผื่อจอเล็ก */
}

/* ห่อเนื้อหาให้ไม่เกินกรอบเว็บ */
.page {
  width: 100%;
  max-width: 1200px;      /* หรือเท่ากรอบเว็บของคุณ */
  margin: 0 auto;
}

/* การ์ดให้ยืดหยุ่นตามจอ ไม่เกินขอบ */
.card-register {
  background: #fff;
  border: none;
  border-radius: 16px;
  padding: 28px 24px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  width: clamp(320px, 92vw, 520px);  /* << ป้องกันล้นขอบ */
  animation: fadeIn 0.5s ease-in-out;
}

.card-register h2 {
  color: #0d6efd;
  font-weight: 600;
  margin-bottom: 20px;
  text-align: center;
}

.form-control {
  border-radius: 10px;
  padding: 12px 15px;
}

.form-control:focus {
  border-color: #0d6efd;
  box-shadow: 0 0 0 0.2rem rgba(13,110,253,.25);
}

.btn-primary {
  background-color: #0d6efd;
  border: none;
  border-radius: 10px;
  padding: 12px;
  font-weight: 500;
  transition: background 0.3s ease;
}

.btn-primary:hover { background-color: #0b5ed7; }

.btn-outline-primary { border-radius: 10px; }

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(30px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* จอเล็กมาก ให้ลด padding ลงอีกนิด */
@media (max-width: 380px) {
  .card-register { padding: 20px 16px; }
}
  </style>
</head>
<body>

  <div class="card-register">
    <h2><i class="fa-solid fa-user-plus"></i> สมัครสมาชิก</h2>
    <form action="Register.php" method="POST">

      <div class="mb-3">
        <label for="name" class="form-label">ชื่อ</label>
        <input type="text" name="name" class="form-control" placeholder="ชื่อ" required>
      </div>

      <div class="mb-3">
        <label for="surname" class="form-label">นามสกุล</label>
        <input type="text" name="surname" class="form-control" placeholder="นามสกุล" required>
      </div>

      <div class="mb-3">
        <label for="username" class="form-label">ชื่อผู้ใช้</label>
        <input type="text" name="username" class="form-control" placeholder="Username" required>
      </div>

      <div class="mb-3">
        <label for="password" class="form-label">รหัสผ่าน</label>
        <input type="password" name="password" class="form-control" placeholder="Password" minlength="8" required>
      </div>

      <div class="mb-3">
        <label for="email" class="form-label">อีเมล</label>
        <input type="email" name="email" class="form-control" placeholder="Email" required>
      </div>

      <div class="mb-3">
        <label for="tel" class="form-label">เบอร์โทร</label>
        <input type="text" name="tel" class="form-control" placeholder="เบอร์โทร" required>
      </div>

      <div class="mb-3">
        <label for="address" class="form-label">ที่อยู่</label>
        <textarea name="address" class="form-control" placeholder="ที่อยู่" required></textarea>
      </div>

      <input type="hidden" name="role" value="User">

      <button type="submit" class="btn btn-primary w-100 mt-3">สมัครสมาชิก</button>
    </form>

    <a href="../main/h.php" class="btn btn-outline-primary w-100 mt-3">← กลับหน้าหลัก</a>
  </div>

</body>
</html>
