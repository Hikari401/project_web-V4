<?php
// LoginAndRegister/change_password_login.php
session_start();

// ใช้ condb2.php และเลือกฐานข้อมูล bookshop
require_once __DIR__ . '/../condb.php';
$dbname = "bookshop";
$conn->select_db($dbname);

// ---- CSRF แบบง่าย ----
if (empty($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$success = "";
$error   = "";

// ---- เมื่อกด Submit ----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ตรวจ CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = "การยืนยันฟอร์มไม่ถูกต้อง (CSRF)";
    } else {
        $username         = trim($_POST['username'] ?? '');
        $email            = trim($_POST['email'] ?? '');
        $new_password     = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // ตรวจความครบถ้วน
        if ($username === '' || $email === '' || $new_password === '' || $confirm_password === '') {
            $error = "กรุณากรอกข้อมูลให้ครบถ้วน";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "รูปแบบอีเมลไม่ถูกต้อง";
        } elseif ($new_password !== $confirm_password) {
            $error = "รหัสผ่านใหม่กับการยืนยันไม่ตรงกัน";
        } elseif (strlen($new_password) < 8) {
            $error = "รหัสผ่านใหม่ควรมีอย่างน้อย 8 ตัวอักษร";
        } else {
            // ค้นหาผู้ใช้จาก username + email
            $sql  = "SELECT uid, password FROM user WHERE username = ? AND email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $res  = $stmt->get_result();
            $user = $res->fetch_assoc();

            if (!$user) {
                $error = "ไม่พบบัญชีที่ตรงกับชื่อผู้ใช้และอีเมล";
            } elseif (password_verify($new_password, $user['password'])) {
                $error = "รหัสผ่านใหม่ต้องไม่เหมือนรหัสผ่านเดิม";
            } else {
                // แฮชแล้วอัปเดต
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $upd    = $conn->prepare("UPDATE user SET password = ? WHERE uid = ?");
                $upd->bind_param("si", $hashed, $user['uid']);

                if ($upd->execute()) {
                    $success = "เปลี่ยนรหัสผ่านเรียบร้อยแล้ว! กรุณาเข้าสู่ระบบด้วยรหัสผ่านใหม่";
                    // ป้องกันการ submit ซ้ำ
                    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                } else {
                    $error = "เกิดข้อผิดพลาดในการบันทึกข้อมูล โปรดลองอีกครั้ง";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>เปลี่ยนรหัสผ่าน (หน้า Login)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{
      min-height:100vh; display:flex; align-items:center; justify-content:center;
      background: linear-gradient(135deg,#007bff,#00c6ff);
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      padding: 24px;
    }
    .card{
      width:100%; max-width:480px; border-radius:16px; box-shadow:0 10px 28px rgba(0,0,0,.18);
    }
  </style>
</head>
<body>
  <div class="card p-4 bg-white">
    <h4 class="text-center text-primary mb-2">เปลี่ยนรหัสผ่าน</h4>
    <p class="text-secondary text-center mb-4">ยืนยันด้วยชื่อผู้ใช้ + อีเมล เพื่อกำหนดรหัสผ่านใหม่</p>

    <?php if($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>"/>

      <div class="mb-3">
        <label class="form-label" for="username">ชื่อผู้ใช้ (Username)</label>
        <input class="form-control" type="text" id="username" name="username" required>
      </div>

      <div class="mb-3">
        <label class="form-label" for="email">อีเมล</label>
        <input class="form-control" type="email" id="email" name="email" required>
      </div>

      <div class="mb-3">
        <label class="form-label" for="new_password">รหัสผ่านใหม่</label>
        <div class="input-group">
          <input class="form-control" type="password" id="new_password" name="new_password" required minlength="8" pattern=".{8,}">
          <button class="btn btn-outline-secondary" type="button" onclick="toggle('new_password', this)">แสดง</button>
        </div>
        <div class="form-text">อย่างน้อย 8 ตัวอักษร (แนะนำให้มีตัวพิมพ์เล็ก-ใหญ่ ตัวเลข และสัญลักษณ์)</div>
      </div>

      <div class="mb-4">
        <label class="form-label" for="confirm_password">ยืนยันรหัสผ่านใหม่</label>
        <div class="input-group">
          <input class="form-control" type="password" id="confirm_password" name="confirm_password" required>
          <button class="btn btn-outline-secondary" type="button" onclick="toggle('confirm_password', this)">แสดง</button>
        </div>
      </div>

      <button type="submit" class="btn btn-primary w-100">บันทึกการเปลี่ยนแปลง</button>

      <div class="d-flex justify-content-between mt-3">
        <a class="small" href="./Login.php">กลับไปหน้าเข้าสู่ระบบ</a>
      </div>
    </form>
  </div>

  <script>
    function toggle(id, btn){
      const i = document.getElementById(id);
      if(i.type === 'password'){ i.type = 'text'; btn.textContent='ซ่อน'; }
      else { i.type = 'password'; btn.textContent='แสดง'; }
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
