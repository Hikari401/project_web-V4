<?php
require_once __DIR__ . '/../condb.php';
session_start();

// ถ้าไม่ได้ล็อกอินให้ redirect กลับไปหน้า Login
if (!isset($_SESSION['username'])) {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

// ดึงข้อมูล user จาก session
$name = $_SESSION['name'];
$uid  = (int)($_SESSION['uid'] ?? 0);

// รับค่าค้นหา
$search = isset($_GET['q']) ? trim($_GET['q']) : '';

// เตรียม SQL (รายการหนังสือ)
if ($search !== '') {
    $sql = "SELECT * FROM book WHERE title LIKE ? OR author LIKE ?";
    $stmt = $conn->prepare($sql);
    $likeSearch = "%$search%";
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
} else {
    $sql = "SELECT * FROM book";
    $stmt = $conn->prepare($sql);
}
$stmt->execute();
$result = $stmt->get_result();

// HERO: ดึง 5 เล่มล่าสุดสำหรับ Carousel
$heroStmt = $conn->prepare("SELECT bid, title, details, image FROM book ORDER BY bid DESC LIMIT 5");
$heroStmt->execute();
$heroRes = $heroStmt->get_result();

$heroes = [];
while ($r = $heroRes->fetch_assoc()) {
    // resolve path รูป (รองรับไฟล์อัปโหลด + URL)
    $img = '../page_admin/add/uploads/default.jpg';
    if (!empty($r['image'])) {
        $uploadPath = __DIR__ . '/../page_admin/add/' . $r['image'];
        if (file_exists($uploadPath)) {
            $img = '../page_admin/add/' . $r['image'];
        } elseif (filter_var($r['image'], FILTER_VALIDATE_URL)) {
            $img = $r['image'];
        }
    }
    $r['image_resolved'] = $img;
    $heroes[] = $r;
}

if (empty($heroes)) {
    $heroes[] = [
        'bid' => 0,
        'title' => 'ยินดีต้อนรับสู่ร้านหนังสือออนไลน์',
        'details' => 'หนังสือใหม่ หนังสือขายดี และโปรโมชั่นพิเศษรอคุณอยู่!',
        'image_resolved' => 'https://picsum.photos/1200/450?blur=2'
    ];
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ร้านหนังสือออนไลน์ - ยินดีต้อนรับ <?= htmlspecialchars($name) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    /* ถ้า navbar fixed-top ต้องกันเนื้อหาถูกบัง */
    body { padding-top: 80px; }

    /* HERO CAROUSEL: แสดงพอดีกับรูป ไม่ยืด ไม่แตก */
    .hero-carousel { border-radius: 16px; overflow: hidden; }
    .hero-carousel .carousel-item{
      max-height: 450px;             /* จำกัดไม่ให้สูงเกินไป */
      background: #000;              /* เผื่อรูปไม่เต็มจะมีพื้นหลัง */
      text-align: center;
      position: relative;
    }
    .hero-carousel .banner-img{
      max-height: 450px;             /* ไม่ขยายจนแตก */
      width: auto;                    /* กว้างตามสัดส่วนจริง */
      height: auto;                   /* สูงตามสัดส่วนจริง */
      object-fit: contain;            /* ไม่ครอป/ไม่ยืด */
      display: inline-block;
    }
    .hero-caption{
      position: absolute;
      left: 24px; right: 24px; bottom: 20px;
      color:#fff;
      text-align:left;
      text-shadow:0 2px 8px rgba(0,0,0,.45);
      background:rgba(0,0,0,.35);
      padding:16px; border-radius:12px;

      z-index:20;          /* อยู่เหนือ control */
      pointer-events:auto; /* ให้กดได้ */
    }
    .hero-caption .btn{ position:relative; z-index:25; }

    /* ลด z-index ของปุ่มเลื่อนไม่ให้ทับ caption */
    .carousel-control-prev, .carousel-control-next{ z-index:5; }

    .carousel-indicators [data-bs-target]{
      width:8px;height:8px;border-radius:50%;
      background-color:#d0d0d0;
    }
    .carousel-indicators .active{ background:#28a745; }

    .shadow-soft{ box-shadow:0 10px 30px rgba(0,0,0,.08); }

    /* รูปการ์ดหนังสือ */
    .card-img-top{ height:240px; object-fit:cover; }
  </style>
</head>
<body class="bg-light">

<!-- Navbar: ติดบนตลอด -->
<nav class="navbar navbar-expand-lg fixed-top" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <div class="dropdown d-flex align-items-center">
      <button class="btn btn-outline-light dropdown-toggle me-2" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        สวัสดี <?= htmlspecialchars($name) ?>
      </button>
      <ul class="dropdown-menu" aria-labelledby="userDropdown">
        <li><a class="dropdown-item" href="edit/userprofile.php">จัดการบัญชี</a></li>
        <li><a class="dropdown-item" href="order/order_details.php">ประวัติการสั่งซื้อ</a></li>
        <li><a class="dropdown-item" href="pay/formpay.php">แจ้งโอน</a></li>
        <li><a class="dropdown-item" href="../main/h.php">ออกจากระบบ</a></li>
      </ul>
    </div>

    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="user-page.php">BookStore</a>

    <div class="d-flex align-items-center">
      <a href="order/orderview.php" class="btn btn-outline-light me-2 position-relative">
        <i class="bi bi-bag"></i> ตะกร้า
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
          <?php
            $sqlCount = 'SELECT COUNT(*) AS oid FROM order_book WHERE uid = ?';
            $stmtCount = $conn->prepare($sqlCount);
            $stmtCount->bind_param("i", $uid);
            $stmtCount->execute();
            $resCount = $stmtCount->get_result()->fetch_assoc();
            echo (int)$resCount['oid'];
          ?>
        </span>
      </a>

      <!-- ฟอร์มค้นหา -->
      <form class="d-flex" method="get" action="">
        <input class="form-control me-2" type="search" name="q" placeholder="ค้นหาหนังสือ" value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-light" type="submit">ค้นหา</button>
      </form>
    </div>
  </div>
</nav>

<!-- Hero Banner: Carousel -->
<div class="container my-3">
  <div id="heroCarousel" class="carousel slide hero-carousel shadow-soft" data-bs-ride="carousel" data-bs-interval="4200">
    <div class="carousel-indicators" style="bottom:-28px;">
      <?php foreach ($heroes as $i => $_): ?>
        <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $i ?>" class="<?= $i===0?'active':'' ?>" aria-label="Slide <?= $i+1 ?>"></button>
      <?php endforeach; ?>
    </div>

    <div class="carousel-inner">
      <?php foreach ($heroes as $i => $b): ?>
      <div class="carousel-item <?= $i===0?'active':'' ?>">
        <img src="<?= htmlspecialchars($b['image_resolved']) ?>"
             alt="<?= htmlspecialchars($b['title']) ?>"
             class="banner-img"
             onerror="this.onerror=null;this.src='https:'//picsum.photos/1200/450?blur=2';">
        <div class="hero-caption">
          <h3 class="fw-bold mb-1"><?= htmlspecialchars($b['title']) ?></h3>
          <?php if (!empty($b['details'])): ?>
            <p class="mb-3"><?= htmlspecialchars(mb_strimwidth($b['details'], 0, 120, '…', 'UTF-8')) ?></p>
          <?php endif; ?>
          <?php if (!empty($b['bid'])): ?>
            <a href="book_detail.php?bid=<?= (int)$b['bid'] ?>" class="btn btn-light btn-lg">ดูรายละเอียด</a>
          <?php else: ?>
            <a href="#books" class="btn btn-light btn-lg">ดูหนังสือเลย</a>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>

<!-- Book List -->
<div class="container my-5" id="books">
  <h2 class="mb-4">หนังสือแนะนำ</h2>
  <div class="row g-4">
    <?php while($row = $result->fetch_assoc()):
        $stock = (int)$row['stock'];

        // default image
        $imageSrc = '../page_admin/add/uploads/default.jpg';
        if (!empty($row['image'])) {
            $uploadPath = __DIR__ . '/../page_admin/add/' . $row['image'];
            if (file_exists($uploadPath)) {
                $imageSrc = '../page_admin/add/' . $row['image'];
            } elseif (filter_var($row['image'], FILTER_VALIDATE_URL)) {
                $imageSrc = $row['image'];
            }
        }
    ?>
    <div class="col-6 col-md-3">
      <div class="card shadow-sm h-100">
        <a href="book_detail.php?bid=<?= (int)$row['bid'] ?>">
          <img src="<?= $imageSrc ?>"
               class="card-img-top"
               alt="Book Cover"
               onerror="this.onerror=null;this.src='../page_admin/add/uploads/default.jpg';">
        </a>
        <div class="card-body d-flex flex-column">
          <h5 class="card-title mb-1"><?= htmlspecialchars(mb_strimwidth($row['title'],0,60,'…','UTF-8')) ?></h5>
          <p class="card-text text-muted mb-2">ผู้แต่ง: <?= htmlspecialchars($row['author']) ?></p>
          <div class="mt-auto">
            <p class="fw-bold text-danger mb-2">฿<?= number_format($row['price']) ?></p>
            <?php if ($stock > 0): ?>
              <a href="order/addorder.php?bid=<?= (int)$row['bid'] ?>" class="btn btn-primary w-100">ใส่ตะกร้า</a>
            <?php else: ?>
              <button class="btn btn-secondary w-100" disabled>สินค้าหมด</button>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white py-3 mt-5">
  <div class="container text-center">
    <p>© 2025 BookStore | ติดต่อ: info@bookstore.com</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // กันไม่ให้ปุ่มใน hero-caption ไปชนกับการเลื่อนสไลด์
  document.querySelectorAll('.hero-caption a, .hero-caption button').forEach(el=>{
    el.addEventListener('click', e => e.stopPropagation());
  });
</script>
</body>
</html>
