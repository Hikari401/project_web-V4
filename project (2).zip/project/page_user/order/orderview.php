<?php
require_once __DIR__ . '/../../condb.php';
session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['uid'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

$name = $_SESSION['name'];
$uid = $_SESSION['uid'];
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>ร้านหนังสือออนไลน์ - ยินดีต้อนรับ <?php echo htmlspecialchars($name); ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet" />
</head>
<body class="bg-light">

<!-- ✅ Navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <div class="dropdown d-flex align-items-center">
      <button class="btn btn-outline-light dropdown-toggle me-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        สวัสดี <?php echo htmlspecialchars($name); ?>
      </button>
      <ul class="dropdown-menu" aria-labelledby="userDropdown">
        <li><a class="dropdown-item" href="edit/userprofile.php">จัดการบัญชี</a></li>
        <li><a class="dropdown-item" href="order/order_details.php">ประวัติการสั่งซื้อ</a></li>
        <li><a class="dropdown-item" href="../pay/formpay.php">แจ้งโอน</a></li>
        <li><a class="dropdown-item" href="../main/h.php">ออกจากระบบ</a></li>
      </ul>
    </div>

    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="../user-page.php">BookStore</a>

    <div class="d-flex align-items-center">
      <a href="ordervivw.php" class="btn btn-outline-light me-2 position-relative">
        <i class="bi bi-bag"></i> ตะกร้า
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
          <?php
          $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM order_book WHERE uid = ?");
          $stmt->bind_param("i", $uid);
          $stmt->execute();
          $res = $stmt->get_result()->fetch_assoc();
          echo $res['total'] ?? 0;
          ?>
        </span>
      </a>
      <form class="d-flex">
        <input class="form-control" type="search" placeholder="ค้นหาหนังสือ">
      </form>
    </div>
  </div>
</nav>

<!-- ✅ ส่วนของตะกร้า -->
<div class="container my-4">
  <div class="p-4 text-dark rounded-3 bg-white shadow-sm">
    <h2 class="text-center mb-4">📚 ตะกร้าหนังสือ</h2>

    <?php
    $sql = "SELECT book.bid, book.image, book.title, book.price, order_book.oid, order_book.quantity
            FROM book
            INNER JOIN order_book ON book.bid = order_book.bid
            WHERE order_book.uid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    ?>

    <table class="table table-bordered align-middle" id="cartTable">
      <thead class="table-light">
        <tr>
          <th>รูป</th>
          <th>ชื่อหนังสือ</th>
          <th>ราคา (บาท)</th>
          <th>จำนวน</th>
          <th>ราคารวม (บาท)</th>
          <th>ลบ</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()) :
          // default image
        $imageSrc = '../../page_admin/add/uploads/default.jpg';

        if (!empty($row['image'])) {
            $uploadPath = __DIR__ . '../../page_admin/add/' . $row['image'];
            if (file_exists($uploadPath)) {
                $imageSrc = '../../page_admin/add/' . $row['image'];
            } elseif (filter_var($row['image'], FILTER_VALIDATE_URL)) {
                $imageSrc = $row['image'];
            }
        }
          ?>
          <tr data-oid="<?php echo $row['oid']; ?>" data-price="<?php echo $row['price']; ?>">
            <td> <img src="<?= $imageSrc ?>" style="width:80px;"></td>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
            <td><?php echo number_format($row['price'], 2); ?></td>
            <td>
              <input type="number" class="form-control quantity-input" min="1" value="<?php echo $row['quantity']; ?>" style="width:80px;" />
            </td>
            <td class="item-total">0.00</td>
            <td><a href="deleteorder.php?oid=<?php echo $row['oid']; ?>" class="btn btn-danger btn-sm">ลบ</a></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
      <tfoot>
        <tr class="table-light fw-bold">
          <td colspan="4" class="text-end">ราคารวมทั้งหมด:</td>
          <td id="totalPrice" class="text-danger">0.00</td>
          <td></td>
        </tr>
      </tfoot>
    </table>

    <div class="text-end mt-4">
      <a href="../pay/formpay.php" class="btn btn-primary btn-lg">💸 ชำระเงินรวมทั้งหมด</a>
    </div>
  </div>
</div>

<!-- ✅ Script ส่วนการคำนวณและ AJAX -->
<script>
  function updateItemTotal(input) {
    const row = input.closest('tr');
    const price = parseFloat(row.getAttribute('data-price'));
    let quantity = parseInt(input.value);
    if (isNaN(quantity) || quantity < 1) {
      quantity = 1;
      input.value = 1;
    }
    const total = price * quantity;
    row.querySelector('.item-total').textContent = total.toFixed(2);
  }

  function calculateTotal() {
    let sum = 0;
    document.querySelectorAll('#cartTable tbody tr').forEach(row => {
      const qty = parseInt(row.querySelector('.quantity-input').value);
      const price = parseFloat(row.getAttribute('data-price'));
      sum += price * (isNaN(qty) ? 1 : qty);
    });
    document.getElementById('totalPrice').textContent = sum.toFixed(2);
  }

  function sendUpdateQuantity(oid, qty) {
    fetch('update_quantity.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `oid=${encodeURIComponent(oid)}&quantity=${encodeURIComponent(qty)}`
    })
    .then(res => res.json())
    .then(data => {
      if (data.status !== 'success') {
        alert('❌ ไม่สามารถอัปเดตจำนวนสินค้า: ' + (data.message || ''));
      }
    })
    .catch(err => {
      console.error('Error:', err);
    });
  }

  // Event listener เมื่อเปลี่ยนจำนวน
  document.querySelectorAll('.quantity-input').forEach(input => {
    input.addEventListener('input', e => {
      updateItemTotal(e.target);
      calculateTotal();
      const row = e.target.closest('tr');
      const oid = row.getAttribute('data-oid');
      let qty = parseInt(e.target.value);
      if (isNaN(qty) || qty < 1) qty = 1;
      sendUpdateQuantity(oid, qty);
    });
  });

  // เมื่อโหลดหน้า → คำนวณราคารวม
  window.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.quantity-input').forEach(input => {
      updateItemTotal(input);
    });
    calculateTotal();
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>