<?php
require_once __DIR__ . '/../../condb.php';
session_start();

if (!isset($_SESSION['uid'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$uid = $_SESSION['uid'];
$oid = isset($_POST['oid']) ? intval($_POST['oid']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
if ($quantity < 1) $quantity = 1;

// ดึงราคา book ที่สอดคล้องกับ order นี้
$sqlPrice = "SELECT book.price FROM order_book 
             JOIN book ON order_book.bid = book.bid 
             WHERE order_book.oid = ? AND order_book.uid = ?";
$stmtPrice = $conn->prepare($sqlPrice);
$stmtPrice->bind_param("ii", $oid, $uid);
$stmtPrice->execute();
$resultPrice = $stmtPrice->get_result();
if ($resultPrice->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Order not found']);
    exit();
}
$row = $resultPrice->fetch_assoc();
$price = $row['price'];

// คำนวณ total_amount ใหม่
$total_amount = $price * $quantity;

// อัปเดต quantity และ total_amount
$sqlUpdate = "UPDATE order_book SET quantity = ?, total_amount = ? WHERE oid = ? AND uid = ?";
$stmtUpdate = $conn->prepare($sqlUpdate);
$stmtUpdate->bind_param("diii", $quantity, $total_amount, $oid, $uid);

if ($stmtUpdate->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update']);
}
