<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ปรับ path ตามโฟลเดอร์จริง

if (!isset($_SESSION['uid'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

// รับค่า oid จาก URL
if (isset($_GET['oid'])) {
    $oid = $_GET['oid'];
    $uid = $_SESSION['uid'];

    // ตรวจสอบว่า order นี้เป็นของผู้ใช้หรือไม่ (ความปลอดภัย)
    $check = $conn->prepare("SELECT * FROM order_book WHERE oid = ? AND uid = ?");
    $check->bind_param("ii", $oid, $uid);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // ลบ order
        $stmt = $conn->prepare("DELETE FROM order_book WHERE oid = ?");
        $stmt->bind_param("i", $oid);
        if ($stmt->execute()) {
            echo "<script>alert('ลบรายการสำเร็จ'); window.location='orderview.php';</script>";
            exit();
        } else {
            echo "<script>alert('เกิดข้อผิดพลาดในการลบ'); window.location='orderview.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('ไม่พบข้อมูลหรือคุณไม่มีสิทธิ์ลบรายการนี้'); window.location='orderview.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('ไม่พบรายการที่ต้องการลบ'); window.location='orderview.php';</script>";
    exit();
}
?>
