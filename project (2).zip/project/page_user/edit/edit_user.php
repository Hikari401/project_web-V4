<?php
session_start();
require_once __DIR__ . '/../../condb.php';

// ตรวจสอบการล็อกอิน
if (!isset($_SESSION['username'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

$uid = $_SESSION['uid'];

// ดึงข้อมูลจาก DB
$sql = "SELECT username, email, tel, name, surname, role, address FROM user WHERE uid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $uid);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// อัปเดตข้อมูล
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email    = $_POST['email'];
    $tel      = $_POST['tel'];
    $name     = $_POST['name'];
    $surname  = $_POST['surname'];
    $display  = $_POST['display'] ?? $user['username']; 
    $address   = $_POST['address'];

    $update_sql = "UPDATE user SET email=?, tel=?,address=? ,name=?, surname=? WHERE uid=?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sssssi", $email, $tel,$address, $name, $surname, $uid);

    if ($stmt->execute()) {
        echo "<script>alert('อัปเดตข้อมูลเรียบร้อย'); window.location='userprofile.php';</script>";
        exit();
    } else {
        echo "<script>alert('เกิดข้อผิดพลาด: " . $conn->error . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>แก้ไขข้อมูลส่วนตัว</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .modal-box {
      max-width: 500px;
      margin: 30px auto;
      background: #fff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body class="bg-light">

<div class="modal-box">
  <h4 class="text-center mb-4">แก้ไขข้อมูลส่วนตัว</h4>
  
  <form method="post">
    <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>

    <div class="mb-3">
      <label>Display Name</label>
      <input type="text" class="form-control" name="display" value="<?php echo htmlspecialchars($user['username']); ?>">
    </div>
    
    <div class="row mb-3">
      <div class="col">
        <label>Email</label>
        <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
      </div>
      <div class="col">
        <label>Phone</label>
        <input type="text" class="form-control" name="tel" value="<?php echo htmlspecialchars($user['tel']); ?>">
      </div>
    </div>
    
    <div class="row mb-3">
      <div class="col">
        <label>Firstname</label>
        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user['name']); ?>">
      </div>
      <div class="col">
        <label>Lastname</label>
        <input type="text" class="form-control" name="surname" value="<?php echo htmlspecialchars($user['surname']); ?>">
      </div>
    </div>
    <div class="mb-3">
      <label>Address</label>
      <textarea class="form-control" name="address" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
    </div>
    
    
    <div class="text-center">
      <button type="submit" class="btn btn-success w-100">บันทึกข้อมูล</button>
    </div>
  </form>
</div>

</body>
</html>
