<?php
session_start();
require_once __DIR__ . '/../../condb.php';

if (!isset($_SESSION['uid'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

$uid = $_SESSION['uid'];
$password_input = $_POST['password'] ?? '';

// ดึงรหัสผ่านจากฐานข้อมูล
$sql = "SELECT password FROM user WHERE uid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $uid);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user || !password_verify($password_input, $user['password'])) {
    echo "<script>alert('รหัสผ่านไม่ถูกต้อง'); window.location='confirm_delete.php';</script>";
    exit();
}

// ถ้ารหัสผ่านถูกต้อง — ลบผู้ใช้
$delete_sql = "DELETE FROM user WHERE uid = ?";
$delete_stmt = $conn->prepare($delete_sql);
$delete_stmt->bind_param("i", $uid);

if ($delete_stmt->execute()) {
    session_unset();
    session_destroy();
    echo "<script>alert('บัญชีของคุณถูกลบเรียบร้อยแล้ว'); window.location='../../LoginAndRegister/Login.php';</script>";
    exit();
} else {
    echo "<script>alert('เกิดข้อผิดพลาดในการลบบัญชี'); window.location='userprofile.php';</script>";
    exit();
}
?>
