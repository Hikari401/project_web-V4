<?php
session_start();
require_once __DIR__ . '/../../condb.php';

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือไม่
if (!isset($_SESSION['uid'])) {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

$uid = $_SESSION['uid'];
$name = $_SESSION['name'] ?? 'ผู้ใช้';

// เลือกฐานข้อมูล
$dbname = "bookshop";
if (!$conn->select_db($dbname)) {
    die("Error selecting database: " . $conn->error);
}

// ดึงประวัติการสั่งซื้อของผู้ใช้
$sqlOrders = "SELECT od.order_number, b.title, b.author, od.quantity, od.price, od.status, od.order_date
              FROM order_details od
              INNER JOIN book b ON od.bid = b.bid
              WHERE od.uid = ?
              ORDER BY od.order_date DESC";
$stmtOrders = $conn->prepare($sqlOrders);
$stmtOrders->bind_param("i", $uid);
$stmtOrders->execute();
$resultOrders = $stmtOrders->get_result();

// นับจำนวนรายการในตะกร้า
$sqlCount = 'SELECT COUNT(*) AS oid FROM order_book WHERE uid = ?';
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->bind_param("i", $uid);
$stmtCount->execute();
$resCount = $stmtCount->get_result()->fetch_assoc();
$cartCount = (int)$resCount['oid'];

// --- การค้นหาหนังสือ ---
$search = $_GET['q'] ?? '';
$search = trim($search);

if (!empty($search)) {
    $sqlBooks = "SELECT * FROM book WHERE title LIKE ? OR author LIKE ?";
    $stmtBooks = $conn->prepare($sqlBooks);
    $likeSearch = "%$search%";
    $stmtBooks->bind_param("ss", $likeSearch, $likeSearch);
} else {
    $sqlBooks = "SELECT * FROM book";
    $stmtBooks = $conn->prepare($sqlBooks);
}
$stmtBooks->execute();
$resultBooks = $stmtBooks->get_result();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประวัติการสั่งซื้อ - <?= htmlspecialchars($name) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f4f4f4; }
        table th, table td { text-align: center; vertical-align: middle; }
        table th { background-color: #007acc; color: white; }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <div class="dropdown d-flex align-items-center">
      <button class="btn btn-outline-light dropdown-toggle me-2" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        สวัสดี <?= htmlspecialchars($name) ?>
      </button>
      <ul class="dropdown-menu" aria-labelledby="userDropdown">
        <li><a class="dropdown-item" href="../edit/userprofile.php">จัดการบัญชี</a></li>
        <li><a class="dropdown-item" href="order_details.php">ประวัติการสั่งซื้อ</a></li>
        <li><a class="dropdown-item" href="../pay/formpay.php">แจ้งโอน</a></li>
        <li><a class="dropdown-item" href="../../main/h.php">ออกจากระบบ</a></li>
      </ul>
    </div>

    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="../user-page.php">BookStore</a>

    <div class="d-flex align-items-center">
      <a href="orderview.php" class="btn btn-outline-light me-2 position-relative">
        <i class="bi bi-bag"></i> ตะกร้า
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
          <?= $cartCount ?>
        </span>
      </a>

      <!-- ฟอร์มค้นหา -->
      <form class="d-flex" method="get" action="../user-page.php">
        <input class="form-control me-2" type="search" name="q" placeholder="ค้นหาหนังสือ" value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-light" type="submit">ค้นหา</button>
      </form>
    </div>
  </div>
</nav>

<div class="container my-5">
    <h2 class="text-center mb-4">ประวัติการสั่งซื้อของคุณ</h2>

    <?php if ($resultOrders->num_rows > 0): ?>
        <div class="table-responsive">
        <table class="table table-bordered shadow-sm bg-white">
           <thead>
    <tr>
        <th>ชื่อหนังสือ</th>
        <th>ผู้แต่ง</th>
        <th>จำนวน</th>
        <th>ราคาต่อชิ้น (บาท)</th>
        <th>สถานะ</th>
        <th>วันที่สั่งซื้อ</th>
    </tr>
</thead>
<tbody>
<?php
$lastOrderNumber = null;
$orderTotal = 0;

$orderRows = []; // เก็บแถวไว้ชั่วคราวก่อนแสดง
while($row = $resultOrders->fetch_assoc()):
    $currentOrderNumber = $row['order_number'];

    // ถ้าเจอคำสั่งซื้อใหม่
    if ($currentOrderNumber !== $lastOrderNumber && $lastOrderNumber !== null) {
        // แสดงแถวที่เก็บไว้ก่อนหน้า
        echo "<tr class='table-warning fw-bold'><td colspan='7' class='text-end'>💰 ยอดรวมคำสั่งซื้อ: ฿" . number_format($orderTotal, 2) . "</td></tr>";
        $orderTotal = 0;
    }

    // ถ้าเป็นคำสั่งใหม่ แสดงหัวคำสั่งซื้อ
    if ($currentOrderNumber !== $lastOrderNumber):
?>
        <tr class="table-primary fw-bold">
            <td colspan="7">🧾 หมายเลขคำสั่งซื้อ: <?= htmlspecialchars($currentOrderNumber) ?></td>
        </tr>
<?php
    endif;

    $itemTotal = $row['quantity'] * $row['price'];
    $orderTotal += $itemTotal;
?>
    <tr>
        
        <td><?= htmlspecialchars($row['title']) ?></td>
        <td><?= htmlspecialchars($row['author']) ?></td>
        <td><?= intval($row['quantity']) ?></td>
        <td><?= number_format($row['price'], 2) ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td><?= htmlspecialchars($row['order_date']) ?></td>
    </tr>

<?php
    $lastOrderNumber = $currentOrderNumber;
endwhile;

// แสดงยอดรวมของคำสั่งสุดท้าย
if ($orderTotal > 0):
?>
    <tr class="table-warning fw-bold">
        <td colspan="7" class="text-end">💰 ยอดรวมคำสั่งซื้อ: ฿<?= number_format($orderTotal, 2) ?></td>
    </tr>
<?php endif; ?>
</tbody>
        </table>
        </div>
    <?php else: ?>
        <p class="text-center text-danger">คุณยังไม่มีประวัติการสั่งซื้อ</p>
    <?php endif; ?>

    <!-- ผลลัพธ์การค้นหา -->
    <?php if(!empty($search)): ?>
      <div class="mt-5">
        <h3 class="mb-3">ผลลัพธ์การค้นหา: "<?= htmlspecialchars($search) ?>"</h3>
        <div class="row g-4">
          <?php while($row = $resultBooks->fetch_assoc()):
            $stock = (int)$row['stock'];
            $imageSrc = '../../page_admin/add/uploads/default.jpg';
            if(!empty($row['image'])){
              $uploadPath = __DIR__ . '/../../page_admin/add/' . $row['image'];
              if(file_exists($uploadPath)) $imageSrc = '../../page_admin/add/'.$row['image'];
              elseif(filter_var($row['image'], FILTER_VALIDATE_URL)) $imageSrc = $row['image'];
            }
          ?>
          <div class="col-md-3">
            <div class="card shadow-sm">
              <a href="../book_detail.php?bid=<?= $row['bid'] ?>">
                <img src="<?= $imageSrc ?>" class="card-img-top" alt="Book Cover" onerror="this.onerror=null;this.src='../../page_admin/add/uploads/default.jpg';">
              </a>
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
                <p class="card-text text-muted">ผู้แต่ง: <?= htmlspecialchars($row['author']) ?></p>
                <p class="fw-bold text-danger">฿<?= $row['price'] ?></p>
                <?php if ($stock > 0): ?>
                  <a href="../order/addorder.php?bid=<?= $row['bid'] ?>" class="btn btn-primary w-100">ใส่ตะกร้า</a>
                <?php else: ?>
                  <button class="btn btn-secondary w-100" disabled>สินค้าหมด</button>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="../user-page.php" class="btn btn-primary">กลับไปหน้าหลัก</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
