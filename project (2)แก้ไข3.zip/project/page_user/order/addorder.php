<?php 
require_once __DIR__ . '/../../condb.php';
session_start();

// ตรวจสอบล็อกอิน
if (!isset($_SESSION['username'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

$uid = $_SESSION['uid'];

// รับค่า bid และ quantity จาก POST ก่อน ถ้าไม่มีให้ลอง GET
$bid = isset($_POST['bid']) ? intval($_POST['bid']) : (isset($_GET['bid']) ? intval($_GET['bid']) : null);
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : (isset($_GET['quantity']) ? intval($_GET['quantity']) : 1);

// ตรวจสอบค่าที่รับมา
if (!$bid) {
    die("เกิดข้อผิดพลาด: ไม่พบ ID หนังสือ");
}
if ($quantity < 1) $quantity = 1;

// ดึงราคาหนังสือและ stock
$sql = "SELECT price, stock FROM book WHERE bid=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $bid);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();

if (!$book) {
    die("ไม่พบหนังสือที่เลือก");
}

$price = $book['price'];
$stock = $book['stock'];

// ตรวจสอบ stock
if ($stock < $quantity) {
    die("❌ สต็อกหนังสือไม่เพียงพอ ไม่สามารถสั่งซื้อได้");
}

$total_amount = $price * $quantity;
$order_date = date("Y-m-d");

// เพิ่มคำสั่งซื้อ พร้อมจำนวนและยอดรวม
$insert = "INSERT INTO order_book(uid, bid, order_date, quantity, total_amount) 
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity), total_amount = total_amount + VALUES(total_amount)";
$stmt2 = $conn->prepare($insert);
$stmt2->bind_param("iisid", $uid, $bid, $order_date, $quantity, $total_amount);

if ($stmt2->execute()) {
    header("Location: ../user-page.php");
    exit();
} else {
    die("เกิดข้อผิดพลาดในการเพิ่มคำสั่งซื้อ");
}
?>
