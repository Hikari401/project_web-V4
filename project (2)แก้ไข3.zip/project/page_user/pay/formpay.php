<?php 
require_once __DIR__ . '/../../condb.php';
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ชำระเงิน</title>

  <!-- Bootstrap 5 CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Google Fonts for Modern Look -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(135deg, #f0f4ff 0%, #d9e8ff 100%);
      font-family: 'Roboto', sans-serif;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .payment-card {
      max-width: 480px;
      width: 100%;
      padding: 30px 25px;
      border-radius: 20px;
      background-color: #ffffff;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .payment-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }

    .qr-image {
      width: 200px;
      max-width: 80%;
      border-radius: 15px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
      margin: 0 auto;
      display: block;
    }

    .account-number {
      font-size: 1.6rem;
      color: #0d6efd;
      font-weight: 700;
      text-align: center;
      margin-top: 10px;
    }

    h3 {
      font-weight: 700;
      color: #343a40;
    }

    p.text-muted {
      font-size: 0.95rem;
    }

    .btn-success {
      font-size: 1.1rem;
      padding: 12px;
      border-radius: 12px;
      font-weight: 500;
      transition: all 0.3s;
    }

    .btn-success:hover {
      background-color: #0b5ed7;
      border-color: #0b5ed7;
    }
  </style>
</head>
<body>

  <div class="payment-card text-center">
      <h3>📚 ชำระค่าหนังสือ</h3>
      <p class="text-muted mb-4">สามารถชำระเงินผ่าน QR Code หรือโอนผ่านบัญชีธนาคาร</p>
      
      <img src="pay.jpg" alt="QR Code สำหรับชำระเงิน" class="qr-image mb-4">

      <h5 class="mb-2">💳 โอนผ่านบัญชีธนาคารกรุงไทย</h5>
      <p class="account-number mb-4">123-4-56789-0</p>

      <a href="uploadform.php" class="btn btn-success w-100">📤 แจ้งการโอนเงิน</a>
  </div>

</body>
</html>
