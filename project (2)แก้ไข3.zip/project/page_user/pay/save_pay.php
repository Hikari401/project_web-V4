<?php
require_once __DIR__ . '/../../condb.php';
session_start();
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>ผลการชำระเงิน</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
        background-color: #f8f9fa;
    }
    .container {
        max-width: 600px;
        margin-top: 60px;
    }
    .card {
        border-radius: 15px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="container">
  <div class="card p-4">
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uid = intval($_POST['uid']);
    $amount = floatval($_POST['amount']);
    $method = $_POST['method'];
    $slip = "";

    // อัปโหลดสลิป
    if (isset($_FILES['slip']) && $_FILES['slip']['error'] === 0) {
        $ext = pathinfo($_FILES['slip']['name'], PATHINFO_EXTENSION);
        $newName = uniqid() . '.' . $ext;
        $uploadDir = "uploads/";
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        move_uploaded_file($_FILES['slip']['tmp_name'], $uploadDir . $newName);
        $slip = $newName;
    }

    // ดึงรายการ order ทั้งหมดของ user
    $sql = "SELECT * FROM order_book WHERE uid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $ordersResult = $stmt->get_result();

    $orders = [];
    while ($row = $ordersResult->fetch_assoc()) {
        $orders[] = $row;
    }

    if (count($orders) === 0) {
        echo "<div class='alert alert-danger text-center'>❌ ไม่พบรายการที่ต้องชำระเงิน</div>";
        echo "<div class='text-center mt-3'><a href='../user-page.php' class='btn btn-secondary'>กลับหน้าหลัก</a></div>";
        exit();
    }

    // ✅ สร้าง order_number ใหม่ ก่อน insert
    $orderNumResult = $conn->query("SELECT order_number FROM order_details ORDER BY odid DESC LIMIT 1");
    $lastOrderNumber = 'ORDER0000';
    if ($row = $orderNumResult->fetch_assoc()) {
        $lastOrderNumber = $row['order_number'];
    }
    $lastNumber = intval(substr($lastOrderNumber, 5));
    $newOrderNumber = 'ORDER' . str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);

    // ✅ เพิ่มข้อมูล payment พร้อม order_number
    $insertPayment = $conn->prepare("INSERT INTO payment (uid, order_number, amount, method, slip) VALUES (?, ?, ?, ?, ?)");
    $insertPayment->bind_param("isdss", $uid, $newOrderNumber, $amount, $method, $slip);

    if (!$insertPayment->execute()) {
        echo "<div class='alert alert-danger text-center'>❌ เกิดข้อผิดพลาดขณะบันทึกข้อมูลชำระเงิน: " . htmlspecialchars($insertPayment->error) . "</div>";
        exit();
    }

    // ดึง pid ล่าสุดที่เพิ่มเข้ามา (ไม่จำเป็นในที่นี้ แต่เก็บไว้เผื่อใช้ต่อ)
    $payment_pid = $conn->insert_id;

    // ✅ เพิ่มข้อมูลลง order_details
    $insertDetail = $conn->prepare("INSERT INTO order_details (uid, bid, oid, order_number, quantity, price) VALUES (?, ?, ?, ?, ?, ?)");
    $getPriceStmt = $conn->prepare("SELECT price FROM book WHERE bid = ?");

    foreach ($orders as $order) {
        $bid = $order['bid'];
        $quantity = $order['quantity'];
        $oid = $order['oid']; // ใช้ oid เดิม

        // ดึงราคาหนังสือ
        $getPriceStmt->bind_param("i", $bid);
        $getPriceStmt->execute();
        $priceResult = $getPriceStmt->get_result();
        $book = $priceResult->fetch_assoc();
        $price = $book ? $book['price'] : 0;

        // เพิ่มลง order_details
        $insertDetail->bind_param("iiisid", $uid, $bid, $oid, $newOrderNumber, $quantity, $price);

        if (!$insertDetail->execute()) {
            echo "<div class='alert alert-danger text-center'>❌ เกิดข้อผิดพลาด: " . htmlspecialchars($insertDetail->error) . "</div>";
            exit();
        }
    }
    $getPriceStmt->close();
    $insertDetail->close();

    // ✅ ล้างตะกร้า
    $deleteCart = $conn->prepare("DELETE FROM order_book WHERE uid = ?");
    $deleteCart->bind_param("i", $uid);
    $deleteCart->execute();

    // ✅ แสดงผลลัพธ์
    echo "<div class='alert alert-success text-center fw-bold'>✅ ชำระเงินสำเร็จ และบันทึกรายการสั่งซื้อแล้ว</div>";
    echo "<div class='text-center mt-3'>";
    echo "<a href='../user-page.php' class='btn btn-success btn-lg'>กลับหน้าหลัก</a>";
    echo "</div>";
}
?>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
