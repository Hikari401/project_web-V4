<?php
require_once __DIR__ . '/../../condb.php';
session_start();

// ถ้าไม่ได้ล็อกอินให้ redirect กลับไปหน้า Login
if (!isset($_SESSION['username'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}

// ดึง uid และชื่อผู้ใช้จาก session
$uid = $_SESSION['uid'];
$name = $_SESSION['name']; 

// query ข้อมูลผู้ใช้
$sql = "SELECT username, email, name, surname, tel ,address
        FROM user 
        WHERE uid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $uid);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// --- การค้นหาหนังสือ ---
$search = $_GET['q'] ?? '';
$search = trim($search);

if (!empty($search)) {
    $sqlBooks = "SELECT * FROM book WHERE title LIKE ? OR author LIKE ?";
    $stmtBooks = $conn->prepare($sqlBooks);
    $likeSearch = "%$search%";
    $stmtBooks->bind_param("ss", $likeSearch, $likeSearch);
} else {
    $sqlBooks = "SELECT * FROM book";
    $stmtBooks = $conn->prepare($sqlBooks);
}
$stmtBooks->execute();
$resultBooks = $stmtBooks->get_result();
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>จัดการบัญชี - <?= htmlspecialchars($name) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="flex flex-col min-h-screen bg-gray-50 font-sans">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <!-- ซ้าย: ชื่อผู้ใช้ -->
    <div class="dropdown d-flex align-items-center">
      <button class="btn btn-outline-light dropdown-toggle me-2" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
        สวัสดี <?= htmlspecialchars($name) ?>
      </button>
      <ul class="dropdown-menu" aria-labelledby="userDropdown">
        <li><a class="dropdown-item" href="userprofile.php">จัดการบัญชี</a></li>
        <li><a class="dropdown-item" href="../order/order_details.php">ประวัติการสั่งซื้อ</a></li>
        <li><a class="dropdown-item" href="../pay/formpay.php">แจ้งโอน</a></li>
        <li><a class="dropdown-item" href="../../main/h.php">ออกจากระบบ</a></li>
      </ul>
    </div>

    <!-- โลโก้กลาง -->
    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="../../page_user/user-page.php">
      BookStore
    </a>

    <!-- ขวา: ตะกร้า + ค้นหา -->
    <div class="d-flex align-items-center">
      <a href="../order/orderview.php" class="btn btn-outline-light me-2 position-relative">
        <i class="bi bi-bag"></i> ตะกร้า
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
          <?php
          $sqlCount = 'SELECT COUNT(*) AS oid FROM order_book WHERE uid = ?';
          $stmtCount = $conn->prepare($sqlCount);          
          $stmtCount->bind_param("i", $uid);          
          $stmtCount->execute();
          $resCount = $stmtCount->get_result()->fetch_assoc();
          echo (int)$resCount['oid'];
          ?>
        </span>
      </a>

      <!-- ฟอร์มค้นหา -->
      <form class="d-flex" method="get" action="../user-page.php">
        <input class="form-control me-2" type="search" name="q" placeholder="ค้นหาหนังสือ" value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-light" type="submit">ค้นหา</button>
      </form>
    </div>
  </div>
</nav>

<main class="flex-grow">
  <div class="max-w-4xl mx-auto p-6">
    <!-- Title -->
    <h1 class="text-3xl font-bold text-center mb-8">จัดการบัญชี</h1>

    <!-- Profile Section -->
    <div class="flex items-center justify-between bg-white p-6 rounded-2xl shadow">
      <div class="flex items-center space-x-4">
        <div>
          <h2 class="text-xl font-semibold"><?= htmlspecialchars($user['username']) ?></h2>
        </div>
      </div>
      <a href="edit_user.php" class="px-4 py-2 bg-green-500 text-white rounded-full shadow">แก้ไขข้อมูลส่วนตัว</a>
    </div>

    <!-- Account Info -->
    <div class="grid grid-cols-2 gap-6 mt-6">
      <div class="bg-white p-6 rounded-2xl shadow">
        <p><strong>Username:</strong> <?= htmlspecialchars($user['username']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
        <p class="flex items-center">
          <strong>Password:</strong> <span class="ml-2">********</span>
          <a href="edit_password.php" class="ml-4 px-3 py-1 border border-green-500 text-green-600 rounded-full text-sm">
            เปลี่ยนรหัสผ่าน
          </a>
        </p>
      </div>
      <div class="bg-white p-6 rounded-2xl shadow">
        <p><strong>Firstname:</strong> <?= htmlspecialchars($user['name'] ?? '-') ?></p>
        <p><strong>Lastname:</strong> <?= htmlspecialchars($user['surname'] ?? '-') ?></p>
        <p><strong>Phone:</strong> <?= htmlspecialchars($user['tel'] ?? 'ไม่ระบุ') ?></p>
        <p><strong>Address:</strong> <?= htmlspecialchars($user['address'] ?? 'ไม่ระบุ') ?></p>
      </div>
    </div>

    <!-- ผลลัพธ์การค้นหา -->
    <?php if(!empty($search)): ?>
      <div class="mt-8">
        <h2 class="text-2xl mb-4">ผลลัพธ์การค้นหา: "<?= htmlspecialchars($search) ?>"</h2>
        <div class="row g-4">
          <?php while($row = $resultBooks->fetch_assoc()): 
            $stock = (int)$row['stock'];
            $imageSrc = '../page_admin/add/uploads/default.jpg';
            if(!empty($row['image'])){
              $uploadPath = __DIR__ . '/../../page_admin/add/' . $row['image'];
              if(file_exists($uploadPath)) $imageSrc = '../page_admin/add/'.$row['image'];
              elseif(filter_var($row['image'], FILTER_VALIDATE_URL)) $imageSrc = $row['image'];
            }
          ?>
          <div class="col-md-3">
            <div class="card shadow-sm">
              <a href="../../page_user/book_detail.php?bid=<?= $row['bid'] ?>">
                <img src="<?= $imageSrc ?>" class="card-img-top" alt="Book Cover" onerror="this.onerror=null;this.src='../page_admin/add/uploads/default.jpg';">
              </a>
              <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
                <p class="card-text text-muted">ผู้แต่ง: <?= htmlspecialchars($row['author']) ?></p>
                <p class="fw-bold text-danger">฿<?= $row['price'] ?></p>
                <?php if ($stock > 0): ?>
                  <a href="../../page_user/order/addorder.php?bid=<?= $row['bid'] ?>" class="btn btn-primary w-100">ใส่ตะกร้า</a>
                <?php else: ?>
                  <button class="btn btn-secondary w-100" disabled>สินค้าหมด</button>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
    <?php endif; ?>

  </div>

  <!-- Delete Account Section -->
  <div class="max-w-4xl mx-auto mt-8 p-6 bg-white rounded-2xl shadow text-center">
    <form method="POST" action="delete_account.php" onsubmit="return confirm('คุณแน่ใจหรือไม่ว่าต้องการลบบัญชีนี้? การดำเนินการนี้ไม่สามารถย้อนกลับได้!');">
      <a href="confirm_delete.php" class="btn btn-danger px-4 py-2 rounded">ลบบัญชีผู้ใช้</a>
      <p class="text-sm text-muted mt-2 text-gray-500">* เมื่อคุณลบบัญชีแล้ว ข้อมูลจะไม่สามารถกู้คืนได้</p>
    </form>
  </div>

</main>

<!-- Footer -->
<footer class="bg-dark text-white py-3">
  <div class="container text-center">
    <p>© 2025 BookStore | ติดต่อ: info@bookstore.com</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
