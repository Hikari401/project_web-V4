<?php
session_start();
require_once __DIR__ . '/../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบสิทธิ์ admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

$admin_name = $_SESSION['name'];

// ====== สถิติ ======

// ยอดขายวันนี้ (เฉพาะ confirmed)
$sql_sales_today = "SELECT SUM(price * quantity) as total_sales
                    FROM order_details
                    WHERE DATE(order_date) = CURDATE() AND status IN ('confirmed','Item has been shipped.')";
$result_sales_today = $conn->query($sql_sales_today);
$total_sales_today = $result_sales_today->fetch_assoc()['total_sales'] ?? 0;

// คำสั่งซื้อใหม่วันนี้
$sql_orders = "SELECT COUNT(*) as total_orders 
               FROM payment
               WHERE DATE(pay_date) = CURDATE()";
$result_orders = $conn->query($sql_orders);
$total_orders = $result_orders->fetch_assoc()['total_orders'] ?? 0;

// สมาชิกใหม่วันนี้
$sql_users = "SELECT COUNT(*) as new_users 
              FROM user 
              WHERE DATE(created_at) = CURDATE()";
$result_users = $conn->query($sql_users);
$new_users = $result_users->fetch_assoc()['new_users'] ?? 0;

// Stock ต่ำ
$sql_stock = "SELECT COUNT(*) as low_stock 
              FROM book 
              WHERE stock <= 5";
$result_stock = $conn->query($sql_stock);
$low_stock = $result_stock->fetch_assoc()['low_stock'] ?? 0;

// ====== ข้อมูลกราฟ ======

// ยอดขายรายเดือน
$sql_monthly = "SELECT MONTH(order_date) as month, SUM(price * quantity) as sales
                FROM order_details
                WHERE YEAR(order_date) = YEAR(CURDATE()) AND status IN ('confirmed','Item has been shipped.')
                GROUP BY MONTH(order_date)
                ORDER BY MONTH(order_date)";
$result_monthly = $conn->query($sql_monthly);
$months = []; $sales_month = [];
$month_names = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
while($row = $result_monthly->fetch_assoc()){
    $months[] = $month_names[$row['month'] - 1];
    $sales_month[] = $row['sales'];
}

// ยอดขายรายวัน (7 วันล่าสุด)
$sql_daily = "SELECT DATE(order_date) as day, SUM(price * quantity) as sales
              FROM order_details
              WHERE order_date >= CURDATE() - INTERVAL 6 DAY AND status IN ('confirmed','Item has been shipped.')
              GROUP BY DATE(order_date)
              ORDER BY DATE(order_date)";
$result_daily = $conn->query($sql_daily);
$daily_labels = []; $daily_sales = [];
while($row = $result_daily->fetch_assoc()){
    $daily_labels[] = date('d/m', strtotime($row['day']));
    $daily_sales[] = $row['sales'];
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard - BookStore</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body { background-color: #f4f8fb; }
.sidebar {
    height: 100vh;
    background: #0d6efd;
    color: white;
    padding-top: 20px;
}
.sidebar a {
    color: white;
    text-decoration: none;
    display: block;
    padding: 10px;
    border-radius: 8px;
}
.sidebar a:hover { background: rgba(255,255,255,0.2); }
</style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-2 sidebar">
      <h4 class="text-center">📚 Admin</h4>
      <hr>
      <a href="add/bookform.php">📖 จัดการหนังสือ</a>
      <a href="p.php">🛒 จัดการคำสั่งซื้อ</a>
      <a href="add/userform.php">👤 จัดการผู้ใช้</a>
      <a href="order_details_a.php">👤 รายละเอียดการสั่งซื้อ</a>
      <a href="report_sales.php">📊 รายงาน</a>
      <a href="../main/h.php" class="text-danger">🚪 ออกจากระบบ</a>
    </div>

    <!-- Main content -->
    <div class="col-md-10 p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Admin Dashboard</h2>
        <span class="fw-bold">👋 สวัสดี <?php echo htmlspecialchars($admin_name); ?></span>
      </div>

      <!-- Stats Cards -->
      <div class="row g-3 mb-4">
        <div class="col-md-3">
          <div class="card text-bg-primary shadow-sm">
            <div class="card-body">
              <h5>ยอดขายวันนี้</h5>
              <p class="fs-4">฿<?php echo number_format($total_sales_today); ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card text-bg-success shadow-sm">
            <div class="card-body">
              <h5>คำสั่งซื้อใหม่</h5>
              <p class="fs-4"><?php echo $total_orders; ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card text-bg-warning shadow-sm">
            <div class="card-body">
              <h5>สมาชิกใหม่</h5>
              <p class="fs-4"><?php echo $new_users; ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card text-bg-danger shadow-sm">
            <div class="card-body">
              <h5>Stock ต่ำ</h5>
              <p class="fs-4"><?php echo $low_stock; ?> รายการ</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Chart -->
      <div class="card shadow-sm mb-4">
        <div class="card-body">
          <h5 class="card-title">กราฟยอดขาย</h5>
          <button class="btn btn-primary btn-sm" onclick="showChart('month')">รายเดือน</button>
          <button class="btn btn-secondary btn-sm" onclick="showChart('day')">รายวัน (7 วันล่าสุด)</button>
          <div class="mt-3">
            <canvas id="salesChart"></canvas>
            <canvas id="dailyChart" style="display:none;"></canvas>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// กราฟรายเดือน
const ctxMonth = document.getElementById('salesChart');
const chartMonth = new Chart(ctxMonth, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($months); ?>,
        datasets: [{
            label: 'ยอดขายรายเดือน (บาท)',
            data: <?php echo json_encode($sales_month); ?>,
            borderColor: 'rgba(13,110,253,1)',
            backgroundColor: 'rgba(13,110,253,0.2)',
            tension: 0.3,
            fill: true
        }]
    }
});

// กราฟรายวัน
const ctxDay = document.getElementById('dailyChart');
const chartDay = new Chart(ctxDay, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($daily_labels); ?>,
        datasets: [{
            label: 'ยอดขายรายวัน (บาท)',
            data: <?php echo json_encode($daily_sales); ?>,
            backgroundColor: 'rgba(13,110,253,0.5)',
            borderColor: 'rgba(13,110,253,1)',
            borderWidth: 1
        }]
    },
    options: { scales: { y: { beginAtZero: true } } }
});

// สลับกราฟ
function showChart(type){
    if(type === 'month'){
        document.getElementById('salesChart').style.display = 'block';
        document.getElementById('dailyChart').style.display = 'none';
    } else {
        document.getElementById('salesChart').style.display = 'none';
        document.getElementById('dailyChart').style.display = 'block';
    }
}
</script>
</body>
</html>
