<?php
session_start();
require_once __DIR__ . '/../../condb.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "คุณไม่มีสิทธิ์เข้าถึงหน้านี้";
    exit();
}

$uid = intval($_GET['uid'] ?? 0);

if ($uid > 0) {
    $sql = "DELETE FROM user WHERE uid=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $uid);
    if ($stmt->execute()) {
        echo "<script>alert('ลบผู้ใช้สำเร็จ');window.location.href='userform.php';</script>";
    } else {
        echo "<script>alert('เกิดข้อผิดพลาด: ".$conn->error."');window.location.href='userform.php';</script>";
    }
} else {
    echo "<script>alert('UID ไม่ถูกต้อง');window.location.href='user_list.php';</script>";
}
?>
