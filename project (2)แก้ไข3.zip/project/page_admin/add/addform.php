<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>เพิ่มหนังสือ</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            padding: 40px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
        }
        input[type=text], input[type=number], input[type=file], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        button {
            margin-top: 20px;
            background-color: #28a745;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        button:hover {
            background-color: #218838;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            color: #007acc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>เพิ่มหนังสือใหม่</h2>
    <form action="addbook.php" method="post" enctype="multipart/form-data">
        <label for="title">ชื่อหนังสือ</label>
        <input type="text" id="title" name="title" required>

        <label for="author">ผู้แต่ง</label>
        <input type="text" id="author" name="author" required>

        <label for="price">ราคา (บาท)</label>
        <input type="number" id="price" name="price" required min="0">

        <label for="publisher">สำนักพิมพ์</label>
        <input type="text" id="publisher" name="publisher" required>

        <label for="category">หมวดหมู่</label>
        <input type="text" id="category" name="category" required>

        <label for="stock">จำนวนคงเหลือ</label>
        <input type="number" id="stock" name="stock" required min="0">

        <label for="details">รายละเอียด</label>
        <textarea id="details" name="details" placeholder="ใส่รายละเอียดหนังสือ เช่น เนื้อหา สารบัญ ฯลฯ" required></textarea>

        <label for="image_url">URL รูปภาพ (ถ้ามี)</label>
        <input type="text" id="image_url" name="image_url" placeholder="https://example.com/image.jpg">

        <label for="image_file">หรืออัปโหลดรูปภาพ</label>
        <input type="file" id="image_file" name="image_file" accept="image/*">

        <button type="submit">เพิ่มหนังสือ</button>
    </form>
    <a href="bookform.php">[กลับหน้าหลัก]</a>
</div>
</body>
</html>
