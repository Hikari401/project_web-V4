<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่ามีการล็อกอิน admin หรือไม่
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    echo "No admin is logged in.";
    exit();
}

$dbname = "bookshop";
if (!$conn->select_db($dbname)) {
    echo "Error selecting database: " . $conn->error;
    exit();
}

// ตรวจสอบว่ามีการส่งข้อมูลมาหรือยัง
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title     = trim($_POST['title'] ?? '');
    $author    = trim($_POST['author'] ?? '');
    $price     = intval($_POST['price'] ?? 0);
    $publisher = trim($_POST['publisher'] ?? '');
    $category  = trim($_POST['category'] ?? '');
    $stock     = intval($_POST['stock'] ?? 0);
    $details   = trim($_POST['details'] ?? ''); // ✅ เพิ่ม details

    // ตรวจสอบค่าที่จำเป็น
    if (empty($title) || empty($author) || $price <= 0 || $stock < 0) {
        die("<div style='color:red; text-align:center; margin-top:30px;'>❌ กรุณากรอกข้อมูลให้ครบถ้วนและถูกต้อง</div>");
    }

    // กำหนด path รูปภาพ
    $imagePath = '';

    // ถ้ามีการอัปโหลดไฟล์
    if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image_file']['tmp_name'];
        $fileName = $_FILES['image_file']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $uploadDir = __DIR__ . '/uploads/';  
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }
            $destPath = $uploadDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                $imagePath = 'uploads/' . $newFileName; // เก็บเป็น relative path
            } else {
                die("<div style='color:red; text-align:center; margin-top:30px;'>❌ อัปโหลดไฟล์ไม่สำเร็จ</div>");
            }
        } else {
            die("<div style='color:red; text-align:center; margin-top:30px;'>❌ รองรับเฉพาะไฟล์ jpg, jpeg, png, gif</div>");
        }
    } 
    // ถ้าไม่ได้อัปโหลดไฟล์ แต่ใส่ URL มาแทน
    else if (!empty($_POST['image_url'])) {
        $imageUrl = trim($_POST['image_url']);
        if (filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            $imagePath = $imageUrl;
        } else {
            die("<div style='color:red; text-align:center; margin-top:30px;'>❌ URL ไม่ถูกต้อง</div>");
        }
    } else {
        die("<div style='color:red; text-align:center; margin-top:30px;'>❌ กรุณาอัปโหลดไฟล์หรือใส่ URL รูปภาพ</div>");
    }

    // ตรวจสอบหนังสือซ้ำ
    $sql_check = "SELECT * FROM book WHERE title = ? AND author = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("ss", $title, $author);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "<div style='color:red; text-align:center; margin-top:30px;'>❌ หนังสือเล่มนี้มีอยู่แล้ว</div>";
        echo "<div style='text-align:center; margin-top:20px;'><a href='addform.php'>[กลับไปเพิ่มหนังสือ]</a></div>";
        exit();
    }

    // INSERT ใช้คอลัมน์ image และ details
    $sql = "INSERT INTO book (title, author, price, publisher, category, stock, image, details) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("<div style='color:red; text-align:center; margin-top:30px;'>❌ SQL Error: " . $conn->error . "</div>");
    }

    $stmt->bind_param("ssdssiss", $title, $author, $price, $publisher, $category, $stock, $imagePath, $details);

    if ($stmt->execute()) {
        echo "<div style='color:green; text-align:center; margin-top:30px;'>✅ เพิ่มหนังสือสำเร็จ</div>";
        echo "<div style='text-align:center; margin-top:20px;'><a href='bookform.php'>[กลับหน้าหลัก]</a></div>";
    } else {
        echo "<div style='color:red; text-align:center; margin-top:30px;'>❌ เพิ่มหนังสือไม่สำเร็จ: " . $stmt->error . "</div>";
        echo "<div style='text-align:center; margin-top:20px;'><a href='addform.php'>[กลับไปเพิ่ม]</a></div>";
    }
}
?>
