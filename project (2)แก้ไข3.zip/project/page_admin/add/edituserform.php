<?php
session_start();
require_once __DIR__ . '/../../condb.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "คุณไม่มีสิทธิ์เข้าถึงหน้านี้";
    exit();
}

$uid = intval($_GET['uid'] ?? 0);

// ดึงข้อมูลผู้ใช้
$sql = "SELECT * FROM user WHERE uid=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    echo "ไม่พบผู้ใช้";
    exit();
}

// บันทึกการแก้ไข
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $role = $_POST['role'];
    $address = $_POST['address'];

    if (!empty($_POST['password'])) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql = "UPDATE user SET name=?, surname=?, username=?, password=?, email=?, tel=?, role=?, address=? WHERE uid=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssssi", $name, $surname, $username, $password, $email, $tel, $role, $address, $uid);
    } else {
        $sql = "UPDATE user SET name=?, surname=?, username=?, email=?, tel=?, role=?, address=? WHERE uid=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssi", $name, $surname, $username, $email, $tel, $role, $address, $uid);
    }

    if ($stmt->execute()) {
        echo "<script>alert('แก้ไขผู้ใช้สำเร็จ');window.location.href='userform.php';</script>";
    } else {
        echo "<script>alert('เกิดข้อผิดพลาด: ".$conn->error."');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>แก้ไขผู้ใช้</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">แก้ไขผู้ใช้</h2>
    <form method="POST">
        <div class="mb-3">
            <label>ชื่อ</label>
            <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($user['name'])?>" required>
        </div>
        <div class="mb-3">
            <label>นามสกุล</label>
            <input type="text" name="surname" class="form-control" value="<?=htmlspecialchars($user['surname'])?>" required>
        </div>
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" value="<?=htmlspecialchars($user['username'])?>" required>
        </div>
        <div class="mb-3">
            <label>Password (เว้นว่างถ้าไม่เปลี่ยน)</label>
            <input type="password" name="password" class="form-control">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?=htmlspecialchars($user['email'])?>">
        </div>
        <div class="mb-3">
            <label>เบอร์โทร</label>
            <input type="text" name="tel" class="form-control" value="<?=htmlspecialchars($user['tel'])?>">
        </div>
        <div class="mb-3">
            <label>บทบาท</label>
            <select name="role" class="form-control" required>
                <option value="user" <?=$user['role']=='user'?'selected':''?>>User</option>
                <option value="admin" <?=$user['role']=='admin'?'selected':''?>>Admin</option>
            </select>
        </div>
        <div class="mb-3">
            <label>ที่อยู่</label>
            <textarea name="address" class="form-control"><?=htmlspecialchars($user['address'])?></textarea>
        </div>
        <button type="submit" class="btn btn-success">บันทึก</button>
        <a href="userform.php" class="btn btn-secondary">ย้อนกลับ</a>
    </form>
</div>
</body>
</html>
