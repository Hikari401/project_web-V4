<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

$bid = $_GET['bid'] ?? null;
if (!$bid) {
    die("ไม่พบหนังสือที่ต้องแก้ไข");
}

// ดึงข้อมูลหนังสือ
$stmt = $conn->prepare("SELECT * FROM book WHERE bid = ?");
$stmt->bind_param("i", $bid);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();

if (!$book) {
    die("ไม่พบหนังสือที่ต้องแก้ไข");
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แก้ไขหนังสือ</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f0f0;
            padding: 40px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px #ccc;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
        }
        input[type=text], input[type=number], input[type=file], textarea {
            width: 100%;
            padding: 8px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        button {
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            color: #007acc;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .current-img {
            margin-top: 10px;
        }
        .current-img img {
            max-width: 150px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>แก้ไขหนังสือ: <?= htmlspecialchars($book['title']) ?></h2>
    <form action="editbook.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="bid" value="<?= $book['bid'] ?>">

        <label for="title">ชื่อหนังสือ</label>
        <input type="text" id="title" name="title" value="<?= htmlspecialchars($book['title']) ?>" required>

        <label for="author">ผู้แต่ง</label>
        <input type="text" id="author" name="author" value="<?= htmlspecialchars($book['author']) ?>" required>

        <label for="price">ราคา (บาท)</label>
        <input type="number" id="price" name="price" value="<?= $book['price'] ?>" required min="0">

        <label for="publisher">สำนักพิมพ์</label>
        <input type="text" id="publisher" name="publisher" value="<?= htmlspecialchars($book['publisher']) ?>" required>

        <label for="category">หมวดหมู่</label>
        <input type="text" id="category" name="category" value="<?= htmlspecialchars($book['category']) ?>" required>

        <label for="stock">จำนวนคงเหลือ</label>
        <input type="number" id="stock" name="stock" value="<?= $book['stock'] ?>" required min="0">

        <label for="details">รายละเอียด</label>
        <textarea id="details" name="details" placeholder="ใส่รายละเอียดหนังสือ เช่น เนื้อหา สารบัญ ฯลฯ" required><?= htmlspecialchars($book['details']) ?></textarea>

        <label for="image_url">URL รูปภาพ (ถ้ามี)</label>
        <input type="text" id="image_url" name="image_url" value="<?= htmlspecialchars($book['image']) ?>">

        <label for="image_file">หรืออัปโหลดรูปภาพใหม่</label>
        <input type="file" id="image_file" name="image_file" accept="image/*">

        <?php if(!empty($book['image'])): ?>
            <div class="current-img">
                <p>รูปภาพปัจจุบัน:</p>
                <img src="<?= htmlspecialchars($book['image']) ?>" alt="Book Image">
            </div>
        <?php endif; ?>

        <button type="submit">บันทึกการแก้ไข</button>
    </form>
    <a href="../admin-page.php">[กลับหน้าหลัก]</a>
</div>
</body>
</html>
