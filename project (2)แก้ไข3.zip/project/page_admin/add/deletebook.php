<?php
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

$bid=$_REQUEST['bid'];

$sql="DELETE FROM book WHERE bid='$bid'";
if($conn->query($sql)===TRUE){
  include "bookform.php";
}
?>