<?php
require_once __DIR__ . '/../condb.php';  // เชื่อมต่อ DB

// รับค่าเดือนและปีจากฟอร์ม หรือใช้ค่าปัจจุบันเป็น default
$selected_month = isset($_GET['month']) ? (int)$_GET['month'] : date('n');
$selected_year  = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');

// ดึงข้อมูลยอดขายตามเดือนและปีที่เลือก
$sql = "
SELECT b.title, 
       SUM(od.quantity) AS total_qty, 
       SUM(od.quantity * od.price) AS total_sales
FROM order_details od
JOIN book b ON od.bid = b.bid
WHERE od.status != 'rejected'
  AND MONTH(od.order_date) = $selected_month
  AND YEAR(od.order_date) = $selected_year
GROUP BY b.bid
ORDER BY total_sales DESC
";

$result = $conn->query($sql);

// หาวันที่วันนี้
$date_today = date("d/m/Y");

// เตรียมตัวแปรรวมยอด
$sum_qty = 0;
$sum_sales = 0.00;

// รายชื่อเดือน (ภาษาไทย)
$thai_months = [
    1 => 'มกราคม', 2 => 'กุมภาพันธ์', 3 => 'มีนาคม',
    4 => 'เมษายน', 5 => 'พฤษภาคม', 6 => 'มิถุนายน',
    7 => 'กรกฎาคม', 8 => 'สิงหาคม', 9 => 'กันยายน',
    10 => 'ตุลาคม', 11 => 'พฤศจิกายน', 12 => 'ธันวาคม'
];
?>

<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <title>รายงานยอดขายสินค้า</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @media print {
      .no-print { display: none; }
    }
    body {
      font-family: 'TH SarabunPSK', sans-serif;
      font-size: 16px;
    }
    .report-header {
      text-align: center;
      margin-bottom: 30px;
    }
    .report-header h2 {
      margin-bottom: 5px;
    }
    .report-date {
      text-align: right;
      font-size: 14px;
      color: #555;
    }
    tfoot {
      font-weight: bold;
      background-color: #f9f9f9;
    }
  </style>
</head>
<body class="container mt-4">

  <!-- Form เลือกเดือน/ปี -->
  <div class="no-print mb-4">
    <form method="GET" class="row g-2 align-items-end">
      <div class="col-md-3">
        <label for="month" class="form-label">เลือกเดือน</label>
        <select id="month" name="month" class="form-select">
          <?php
          foreach ($thai_months as $num => $name) {
              $selected = ($num == $selected_month) ? "selected" : "";
              echo "<option value='$num' $selected>$name</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-3">
        <label for="year" class="form-label">เลือกปี</label>
        <select id="year" name="year" class="form-select">
          <?php
          $current_year = date('Y');
          for ($y = $current_year; $y >= $current_year - 5; $y--) {
              $selected = ($y == $selected_year) ? "selected" : "";
              echo "<option value='$y' $selected>$y</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-success">ดูรายงาน</button>
      </div>
    </form>
  </div>

  <!-- หัวรายงาน -->
  <div class="report-header">
    <h2>รายงานยอดขายสินค้า</h2>
    <div class="report-date">เดือน <?= $thai_months[$selected_month] ?> <?= $selected_year ?> | อัปเดตวันที่: <?= $date_today ?></div>
  </div>

  <!-- ตารางรายงาน -->
  <table class="table table-bordered table-hover">
    <thead class="table-secondary">
      <tr>
        <th>ลำดับ</th>
        <th>ชื่อสินค้า</th>
        <th class="text-end">จำนวนที่ขายได้</th>
        <th class="text-end">ยอดขายรวม (บาท)</th>
      </tr>
    </thead>
    <tbody>
      <?php
      if ($result && $result->num_rows > 0) {
          $i = 1;
          while ($row = $result->fetch_assoc()) {
              $sum_qty += $row['total_qty'];
              $sum_sales += $row['total_sales'];

              echo "<tr>";
              echo "<td>" . $i++ . "</td>";
              echo "<td>" . htmlspecialchars($row['title']) . "</td>";
              echo "<td class='text-end'>" . number_format($row['total_qty']) . "</td>";
              echo "<td class='text-end'>" . number_format($row['total_sales'], 2) . "</td>";
              echo "</tr>";
          }
      } else {
          echo "<tr><td colspan='4' class='text-center'>ไม่มีข้อมูลยอดขายในเดือนนี้</td></tr>";
      }
      ?>
    </tbody>
    <?php if ($sum_sales > 0): ?>
    <tfoot>
      <tr>
        <td colspan="2" class="text-end">รวมทั้งหมด</td>
        <td class="text-end"><?= number_format($sum_qty) ?></td>
        <td class="text-end"><?= number_format($sum_sales, 2) ?></td>
      </tr>
    </tfoot>
    <?php endif; ?>
  </table>

  <div class="no-print text-center mt-4">
    <button class="btn btn-primary" onclick="window.print()">พิมพ์รายงาน</button>
  </div>

</body>
</html>
