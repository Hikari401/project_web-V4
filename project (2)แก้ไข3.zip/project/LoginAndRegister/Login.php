<?php
require_once __DIR__ . '/../condb.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $conn->select_db("bookshop");

    $stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['username'] = $user['username'];
            $_SESSION['uid'] = $user['uid']; 
            $_SESSION['name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header("Location: ../page_admin/admin-page.php");
                exit();
            } else {
                header("Location: ../page_user/user-page.php");
                exit();
            }
        } else {
            header("Location: Login.php?error=รหัสผ่านไม่ถูกต้อง");
            exit();
        }
    } else {
        header("Location: Login.php?error=ไม่พบผู้ใช้งาน");
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" integrity="sha512-y0YUMGQJzZo6r5AqKz8U5as2B+hfM+NymXQ8u1y5sOB7V9eAcm0t+6GvVZK4EVZ1nYz5CMg+FUz9ZGpvFZUJGA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <style>
    body {
      height: 100vh;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #74ebd5 0%, #ACB6E5 100%);
      font-family: "Prompt", sans-serif;
    }

    .login-card {
      background: #fff;
      border: none;
      border-radius: 15px;
      padding: 40px 35px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      width: 100%;
      max-width: 420px;
      transition: all 0.3s ease-in-out;
    }

    .login-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
    }

    .login-card h2 {
      font-weight: 600;
      color: #0d6efd;
      margin-bottom: 25px;
      text-align: center;
    }

    .form-label {
      font-weight: 500;
      color: #333;
    }

    .form-control {
      border-radius: 10px;
      padding: 12px 15px;
      border: 1px solid #ced4da;
    }

    .form-control:focus {
      border-color: #0d6efd;
      box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
    }

    .btn-login {
      background-color: #0d6efd;
      border: none;
      border-radius: 10px;
      padding: 12px;
      font-size: 1rem;
      font-weight: 500;
      width: 100%;
      margin-top: 10px;
      transition: background-color 0.3s ease;
    }

    .btn-login:hover {
      background-color: #0b5ed7;
    }

    .register-link {
      display: block;
      margin-top: 15px;
      text-align: center;
      font-size: 0.9rem;
      color: #0d6efd;
      text-decoration: none;
    }

    .register-link:hover {
      text-decoration: underline;
    }

    .form-icon {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #aaa;
    }

    .input-group {
      position: relative;
    }

    .form-control.icon-padding {
      padding-left: 40px;
    }

    .back-btn {
      display: block;
      text-align: center;
      margin-top: 20px;
      font-size: 0.9rem;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <h2><i class="fa-solid fa-right-to-bracket"></i> เข้าสู่ระบบ</h2>

    <?php if (isset($_GET['error'])): ?>
      <div class="alert alert-danger" role="alert">
        <?php echo htmlspecialchars($_GET['error']); ?>
      </div>
    <?php endif; ?>

    <form action="Login.php" method="post">
      <!-- Username field -->
      <div class="mb-3 input-group">
        <span class="form-icon"><i class="fa-solid fa-user"></i></span>
        <input type="text" name="username" class="form-control icon-padding" placeholder="กรอกชื่อผู้ใช้" required />
      </div>

      <!-- Password field -->
      <div class="mb-3 input-group">
        <span class="form-icon"><i class="fa-solid fa-lock"></i></span>
        <input type="password" name="password" class="form-control icon-padding" placeholder="กรอกรหัสผ่าน" required />
      </div>

      <!-- Register link -->
      <a href="Register.php" class="register-link">ยังไม่มีบัญชีใช่ไหม? สมัครสมาชิก</a>
      <div class="text-center mt-3">
  <a href="c_password.php" class="small">ลืมรหัสผ่าน / เปลี่ยนรหัสผ่านด้วยอีเมล</a>
</div>

      <!-- Login button -->
      <input type="submit" name="login" class="btn btn-login" value="เข้าสู่ระบบ" />
    </form>

    <!-- Back to homepage -->
    <div class="back-btn">
      <a href="../main/h.php" class="btn btn-outline-secondary w-100 mt-3">
        ← กลับหน้าหลัก
      </a>
    </div>
  </div>
</body>
</html>
