<?php
require_once __DIR__ . '/../condb.php';

/* ---------- รูป: ตัวแก้พาธให้รองรับทั้งชื่อไฟล์/โฟลเดอร์ uploads/ และ URL ---------- */
function resolveBookImage(?string $raw): string {
    $default = '../page_admin/add/uploads/default.jpg';
    if (!$raw || trim($raw) === '') return $default;

    // ถ้าเป็น URL (http/https) ใช้ได้เลย
    if (filter_var($raw, FILTER_VALIDATE_URL)) return $raw;

    // กัน path แปลก ๆ แล้วลองหลายตำแหน่ง
    $name = ltrim($raw, "/\\");
    $name = basename($name); // กัน ../../../
    $baseDir = __DIR__ . '/../page_admin/add/';
    $candidates = [
        [$baseDir . $name,                 '../page_admin/add/' . $name],
        [$baseDir . 'uploads/' . $name,    '../page_admin/add/uploads/' . $name],
    ];
    // ถ้าค่าดิบขึ้นต้นด้วย uploads/ ให้ลองตามนั้นด้วย
    if (str_starts_with($raw, 'uploads/')) {
        $candidates[] = [$baseDir . $raw, '../page_admin/add/' . $raw];
    }
    foreach ($candidates as [$fs, $web]) {
        if (file_exists($fs)) return $web;
    }
    return $default;
}

/* ---------- รับรหัสหนังสือจาก URL ---------- */
if (!isset($_GET['bid'])) die("ไม่พบรหัสหนังสือ");
$bid = intval($_GET['bid']);

/* ---------- ดึงข้อมูลหนังสือ ---------- */
$sql = "SELECT * FROM book WHERE bid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $bid);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();
if (!$book) die("ไม่พบบุ๊ค");
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($book['title']) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <a href="../LoginAndRegister/Login.php" class="btn btn-success me-2">ล็อกอิน</a>
    <a href="../LoginAndRegister/Register.php" class="btn btn-outline-light me-3">สมัครสมาชิก</a>
    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="h.php">BookStore</a>
    <form class="d-flex ms-auto me-3" method="get" action="">
      <input class="form-control me-2" type="search" name="q" placeholder="ค้นหาหนังสือ...">
      <button class="btn btn-outline-light" type="submit">ค้นหา</button>
    </form>
    <a href="../LoginAndRegister/Login.php" class="btn btn-warning">ตะกร้า (0)</a>
  </div>
</nav>

<div class="container mt-4">
  <div class="row">
    <div class="col-md-4">
      <?php $imageSrc = resolveBookImage($book['image'] ?? ''); ?>
      <img
        src="<?= htmlspecialchars($imageSrc) ?>"
        class="img-fluid rounded"
        alt="<?= htmlspecialchars($book['title']) ?>"
        onerror="this.onerror=null;this.src='../page_admin/add/uploads/default.jpg'">
    </div>
    <div class="col-md-8">
      <h2><?= htmlspecialchars($book['title']) ?></h2>
      <p><strong>ผู้เขียน:</strong> <?= htmlspecialchars($book['author']) ?></p>
      <p><strong>สำนักพิมพ์:</strong> <?= htmlspecialchars($book['publisher']) ?></p>
      <p><strong>หมวดหมู่:</strong> <?= htmlspecialchars($book['category']) ?></p>
      <p><strong>ราคา:</strong> <?= number_format((float)$book['price']) ?> บาท</p>
      <p><strong>รายละเอียด:</strong> <?= htmlspecialchars($book['details']) ?></p>
      <p><strong>คงเหลือ:</strong> <?= (int)$book['stock'] ?> เล่ม</p>

      <!-- ปุ่มใส่ตะกร้า (ให้ล็อกอินก่อน) -->
      <?php if ((int)$book['stock'] > 0): ?>
        <a href="../LoginAndRegister/Login.php" class="btn btn-success mt-2">🛒 ใส่ตะกร้า (ล็อกอินก่อน)</a>
      <?php else: ?>
        <button class="btn btn-secondary mt-2" disabled>สินค้าหมด</button>
      <?php endif; ?>
    </div>
  </div>

  <hr>

  <!-- รีวิว -->
  <h4>รีวิวจากผู้อ่าน</h4>
  <p class="text-danger">กรุณา <a href="../LoginAndRegister/Login.php">เข้าสู่ระบบ</a> เพื่อเขียนรีวิว</p>

  <?php
  $sql = "SELECT r.rating, r.comment, r.created_at, u.username
          FROM reviews r
          INNER JOIN user u ON r.uid = u.uid
          WHERE r.bid = ?
          ORDER BY r.created_at DESC";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $bid);
  $stmt->execute();
  $reviews = $stmt->get_result();

  if ($reviews->num_rows > 0) {
      while ($row = $reviews->fetch_assoc()) {
          echo "<div class='card my-2'><div class='card-body'>";
          echo "<h6 class='card-title'>".str_repeat("⭐", (int)$row['rating'])."</h6>";
          echo "<p class='card-text'>".nl2br(htmlspecialchars($row['comment']))."</p>";
          echo "<small class='text-muted'>โดย ".htmlspecialchars($row['username'])." | ".$row['created_at']."</small>";
          echo "</div></div>";
      }
  } else {
      echo "<p>ยังไม่มีรีวิว</p>";
  }
  ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
