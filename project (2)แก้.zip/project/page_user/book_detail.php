<?php
session_start();
require_once __DIR__ . '/../condb.php';

// ตรวจสอบล็อกอิน
if (!isset($_SESSION['username']) || !isset($_SESSION['uid'])) {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

$name = $_SESSION['name']; 
$uid  = (int)$_SESSION['uid'];

// รับค่าค้นหา
$search = trim($_GET['q'] ?? '');

// ดึงข้อมูลหนังสือ
if ($search !== '') {
    $sql = "SELECT * FROM book WHERE title LIKE ? OR author LIKE ?";
    $stmt = $conn->prepare($sql);
    $likeSearch = "%$search%";
    $stmt->bind_param("ss", $likeSearch, $likeSearch);
} else {
    $sql = "SELECT * FROM book";
    $stmt = $conn->prepare($sql);
}
$stmt->execute();
$books = $stmt->get_result();

// ดึงจำนวนสินค้าที่อยู่ในตะกร้า
$sqlCount = "SELECT COUNT(*) AS total FROM order_book WHERE uid=?";
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->bind_param("i", $uid);
$stmtCount->execute();
$cartCount = (int)$stmtCount->get_result()->fetch_assoc()['total'];

// รับรหัสหนังสือสำหรับดูรายละเอียด (ถ้ามี)
$bid = isset($_GET['bid']) ? intval($_GET['bid']) : null;
$bookDetail = null;
if ($bid) {
    $stmtDetail = $conn->prepare("SELECT * FROM book WHERE bid=?");
    $stmtDetail->bind_param("i", $bid);
    $stmtDetail->execute();
    $bookDetail = $stmtDetail->get_result()->fetch_assoc();
}

// ---------------------------------------------
// ตัวแปร/ตรรกะสำหรับโหมดแก้ไขรีวิว
// ---------------------------------------------
$isEditing = false;
$myReview  = null;
if ($bid && isset($_GET['edit'])) {
    // มีการกดแก้ไข -> โหลดรีวิวของผู้ใช้คนนี้ในเล่มนี้
    $stmtMy = $conn->prepare("SELECT bid, uid, rating, comment, created_at FROM reviews WHERE bid=? AND uid=? LIMIT 1");
    $stmtMy->bind_param("ii", $bid, $uid);
    $stmtMy->execute();
    $resMy = $stmtMy->get_result();
    if ($resMy->num_rows === 1) {
        $myReview  = $resMy->fetch_assoc();
        $isEditing = true;
    }
}

// ---------------------------------------------
// ส่งรีวิวใหม่ หรือ อัปเดตรีวิว
// ---------------------------------------------
$reviewMsg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ทำความสะอาดค่ารับมา
    $postRating  = isset($_POST['rating']) ? max(1, min(5, (int)$_POST['rating'])) : null;
    $postComment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
    // จำกัดความยาวกันสแปม (เช่น 2,000 ตัวอักษร)
    if ($postComment !== '' && mb_strlen($postComment) > 2000) {
        $postComment = mb_substr($postComment, 0, 2000);
    }

    // โหมดอัปเดต
    if (isset($_POST['edit_mode']) && isset($_POST['review_bid'])) {
        $review_bid = (int)$_POST['review_bid'];

        // อนุญาตแก้ไขเฉพาะรีวิวของตนเองในเล่มนั้น
        $stmtCheckOwner = $conn->prepare("SELECT 1 FROM reviews WHERE bid=? AND uid=?");
        $stmtCheckOwner->bind_param("ii", $review_bid, $uid);
        $stmtCheckOwner->execute();
        $hasReview = $stmtCheckOwner->get_result()->num_rows === 1;

        if ($hasReview) {

            // FIX: เช็คว่ามีคอลัมน์ updated_at ไหม ถ้ามีค่อยอัปเดตคอลัมน์นั้น
            $hasUpdatedAt = false;
            if ($colRes = $conn->query("SHOW COLUMNS FROM reviews LIKE 'updated_at'")) {
                $hasUpdatedAt = ($colRes->num_rows > 0);
                $colRes->free_result();
            }

            if ($hasUpdatedAt) {
                $stmtUpdate = $conn->prepare("UPDATE reviews SET rating=?, comment=?, updated_at=NOW() WHERE bid=? AND uid=?");
                $stmtUpdate->bind_param("isii", $postRating, $postComment, $review_bid, $uid);
            } else {
                // ไม่มี updated_at -> อัปเดตเฉพาะ rating/comment
                $stmtUpdate = $conn->prepare("UPDATE reviews SET rating=?, comment=? WHERE bid=? AND uid=?");
                $stmtUpdate->bind_param("isii", $postRating, $postComment, $review_bid, $uid);
            }

            $stmtUpdate->execute();
            $reviewMsg = "อัปเดตรีวิวเรียบร้อยแล้ว";
            // รีเซ็ตโหมดแก้ไขหลังอัปเดตสำเร็จ
            $isEditing = false;
            $myReview  = null;

        } else {
            $reviewMsg = "ไม่พบรีวิวของคุณสำหรับเล่มนี้ หรือไม่มีสิทธิ์แก้ไข";
        }
    }
    // โหมดเพิ่มใหม่
    elseif (isset($_POST['review_bid'])) {
        $review_bid = (int)$_POST['review_bid'];

        // ป้องกันรีวิวซ้ำ
        $stmtCheck = $conn->prepare("SELECT 1 FROM reviews WHERE bid=? AND uid=?");
        $stmtCheck->bind_param("ii", $review_bid, $uid);
        $stmtCheck->execute();

        if ($stmtCheck->get_result()->num_rows === 0) {
            $stmtInsert = $conn->prepare("INSERT INTO reviews (bid, uid, rating, comment) VALUES (?, ?, ?, ?)");
            $stmtInsert->bind_param("iiis", $review_bid, $uid, $postRating, $postComment);
            $stmtInsert->execute();
            $reviewMsg = "รีวิวถูกบันทึกแล้ว";
        } else {
            $reviewMsg = "คุณได้รีวิวหนังสือนี้แล้ว (กด “แก้ไข” เพื่ออัปเดตได้)";
            // เปิดโหมดแก้ไขให้เลยเพื่อความสะดวก
            $isEditing = true;
            $bid = $review_bid;
            $stmtMy = $conn->prepare("SELECT bid, uid, rating, comment, created_at FROM reviews WHERE bid=? AND uid=? LIMIT 1");
            $stmtMy->bind_param("ii", $bid, $uid);
            $stmtMy->execute();
            $myReview  = $stmtMy->get_result()->fetch_assoc();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>BookStore - <?= htmlspecialchars($name) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg" style="background: linear-gradient(to right, #007bff, #00c6ff);">
  <div class="container-fluid px-4">
    <div class="dropdown d-flex align-items-center">
      <button class="btn btn-outline-light dropdown-toggle me-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
        สวัสดี <?= htmlspecialchars($name) ?>
      </button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="edit/userprofile.php">จัดการบัญชี</a></li>
        <li><a class="dropdown-item" href="pay/formpay.php">แจ้งโอน</a></li>
        <li><a class="dropdown-item" href="../main/h.php">ออกจากระบบ</a></li>
      </ul>
    </div>
    <a class="navbar-brand mx-auto text-white fw-bold fs-4" href="user-page.php">BookStore</a>
    <div class="d-flex align-items-center">
      <a href="order/orderview.php" class="btn btn-outline-light me-2 position-relative">
        <i class="bi bi-bag"></i> ตะกร้า
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $cartCount ?></span>
      </a>
      <form class="d-flex" method="get">
        <input class="form-control me-2" type="search" name="q" placeholder="ค้นหาหนังสือ" value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-light" type="submit">ค้นหา</button>
      </form>
    </div>
  </div>
</nav>

<div class="container my-4">
<?php if($bookDetail): ?>
  <!-- Book Detail -->
  <div class="row mb-4">
    <div class="col-md-4">
        <?php 
        $imageSrc = '../page_admin/add/uploads/default.jpg';
        if(!empty($bookDetail['image'])){
            $uploadPath = __DIR__ . '/../page_admin/add/' . $bookDetail['image'];
            if(file_exists($uploadPath)) $imageSrc = '../page_admin/add/'.$bookDetail['image'];
            elseif(filter_var($bookDetail['image'], FILTER_VALIDATE_URL)) $imageSrc = $bookDetail['image'];
        }
        ?>
        <img src="<?= $imageSrc ?>" class="img-fluid rounded" alt="<?= htmlspecialchars($bookDetail['title']) ?>" onerror="this.src='../page_admin/add/uploads/default.jpg'">
    </div>
    <div class="col-md-8">
        <h2><?= htmlspecialchars($bookDetail['title']) ?></h2>
        <p><strong>ผู้เขียน:</strong> <?= htmlspecialchars($bookDetail['author']) ?></p>
        <p><strong>สำนักพิมพ์:</strong> <?= htmlspecialchars($bookDetail['publisher']) ?></p>
        <p><strong>หมวดหมู่:</strong> <?= htmlspecialchars($bookDetail['category']) ?></p>
        <p><strong>ราคา:</strong> <?= number_format($bookDetail['price']) ?> บาท</p>
        <p><strong>รายละเอียด:</strong> <?= htmlspecialchars($bookDetail['details']) ?></p>
        <p><strong>คงเหลือ:</strong> <?= (int)$bookDetail['stock'] ?> เล่ม</p>

        <?php if((int)$bookDetail['stock']>0): ?>
        <form method="POST" action="order/addorder.php" class="d-flex mt-3">
            <input type="hidden" name="bid" value="<?= (int)$bookDetail['bid'] ?>">
            <input type="number" name="quantity" value="1" min="1" max="<?= (int)$bookDetail['stock'] ?>" class="form-control w-25 me-2">
            <button type="submit" class="btn btn-success">🛒 ใส่ตะกร้า</button>
        </form>
        <?php else: ?>
            <p class="text-danger">สินค้าหมด</p>
        <?php endif; ?>
    </div>
  </div>

  <!-- Reviews -->
  <h4>รีวิวจากผู้อ่าน</h4>
  <?php
  // ดึง uid ของผู้รีวิวมาด้วย เพื่อตรวจสิทธิ์แสดงปุ่มแก้ไข
  $stmtReviews = $conn->prepare("
      SELECT r.bid, r.uid, r.rating, r.comment, r.created_at, u.username
      FROM reviews r 
      INNER JOIN user u ON r.uid=u.uid 
      WHERE r.bid=? 
      ORDER BY r.created_at DESC
  ");
  $stmtReviews->bind_param("i",$bookDetail['bid']);
  $stmtReviews->execute();
  $reviews = $stmtReviews->get_result();

  if($reviews->num_rows > 0){
      while($row=$reviews->fetch_assoc()){
          echo "<div class='card my-2'><div class='card-body'>";
          echo "<div class='d-flex justify-content-between align-items-start'>";
          echo "<div>";
          echo "<h6 class='mb-1'>".str_repeat("⭐",(int)$row['rating'])."</h6>";
          echo "<p class='mb-1'>".nl2br(htmlspecialchars($row['comment']))."</p>";
          echo "<small class='text-muted'>โดย ".htmlspecialchars($row['username'])." | ".$row['created_at']."</small>";
          echo "</div>";
          // แสดงปุ่มแก้ไขเฉพาะรีวิวของผู้ใช้คนปัจจุบัน
          if ((int)$row['uid'] === $uid) {
              $editLink = "?bid=".(int)$bookDetail['bid']."&edit=1";
              echo "<div><a class='btn btn-sm btn-outline-primary' href='$editLink'>แก้ไข</a></div>";
          }
          echo "</div>";
          echo "</div></div>";
      }
  } else {
      echo "<p>ยังไม่มีรีวิว</p>";
  }
  ?>

  <!-- Form Review -->
  <?php if(isset($_SESSION['uid'])): ?>
    <h5 class="mt-4"><?= $isEditing ? "แก้ไขรีวิวของคุณ" : "เขียนรีวิว" ?></h5>
    <?php if(isset($reviewMsg) && $reviewMsg): ?>
      <div class="alert alert-info"><?= htmlspecialchars($reviewMsg) ?></div>
    <?php endif; ?>

    <form method="POST" class="mb-4">
        <input type="hidden" name="review_bid" value="<?= (int)$bookDetail['bid'] ?>">

        <?php if ($isEditing): ?>
            <!-- โหมดแก้ไข -->
            <input type="hidden" name="edit_mode" value="1">
        <?php endif; ?>

        <label class="form-label">ให้คะแนน:</label>
        <select name="rating" class="form-select w-25 mb-2" required>
            <?php
            // เลือกคะแนนเดิมอัตโนมัติเมื่อแก้ไข
            $currentRating = $isEditing && $myReview ? (int)$myReview['rating'] : 5;
            for ($r=5;$r>=1;$r--) {
                $sel = $r===$currentRating ? 'selected' : '';
                echo "<option value='$r' $sel>".str_repeat("⭐",$r)."</option>";
            }
            ?>
        </select>

        <label class="form-label">รีวิว:</label>
        <textarea name="comment" class="form-control mb-2" rows="4" placeholder="เขียนความเห็นของคุณ..."><?= $isEditing && $myReview ? htmlspecialchars($myReview['comment']) : '' ?></textarea>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-primary">
                <?= $isEditing ? "อัปเดตรีวิว" : "ส่งรีวิว" ?>
            </button>
            <?php if ($isEditing): ?>
                <!-- ปุ่มยกเลิกโหมดแก้ไข -->
                <a class="btn btn-outline-secondary" href="?bid=<?= (int)$bookDetail['bid'] ?>">ยกเลิก</a>
            <?php endif; ?>
        </div>
    </form>
  <?php else: ?>
    <p class="text-danger">กรุณา <a href="../LoginAndRegister/Login.php">เข้าสู่ระบบ</a> เพื่อเขียนรีวิว</p>
  <?php endif; ?>

<?php else: ?>
  <!-- Book List -->
  <h2>หนังสือ</h2>
  <div class="row g-4">
  <?php while($row = $books->fetch_assoc()):
      $stock = (int)$row['stock'];
      $imageSrc = '../page_admin/add/uploads/default.jpg';
      if(!empty($row['image'])){
          $uploadPath = __DIR__ . '/../page_admin/add/' . $row['image'];
          if(file_exists($uploadPath)) $imageSrc = '../page_admin/add/'.$row['image'];
          elseif(filter_var($row['image'], FILTER_VALIDATE_URL)) $imageSrc = $row['image'];
      }
  ?>
    <div class="col-md-3">
      <div class="card shadow-sm">
        <a href="?bid=<?= (int)$row['bid'] ?>">
          <img src="<?= $imageSrc ?>" class="card-img-top" alt="<?= htmlspecialchars($row['title']) ?>" onerror="this.src='../page_admin/add/uploads/default.jpg'">
        </a>
        <div class="card-body">
          <h5 class="card-title"><?= htmlspecialchars($row['title']) ?></h5>
          <p class="text-muted">ผู้แต่ง: <?= htmlspecialchars($row['author']) ?></p>
          <p class="fw-bold text-danger">฿<?= number_format($row['price']) ?></p>
          <?php if($stock>0): ?>
            <a href="order/addorder.php?bid=<?= (int)$row['bid'] ?>" class="btn btn-primary w-100">ใส่ตะกร้า</a>
          <?php else: ?>
            <button class="btn btn-secondary w-100" disabled>สินค้าหมด</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endwhile; ?>
  </div>
<?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
