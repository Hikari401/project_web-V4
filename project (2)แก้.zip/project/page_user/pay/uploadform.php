<?php
require_once __DIR__ . '/../../condb.php';
session_start();

if (!isset($_SESSION['username']) || !isset($_SESSION['uid'])) {
    header("Location: ../LoginAndRegister/Login.php");
    exit();
}

$uid = $_SESSION['uid'];
$name = $_SESSION['name'];

// รวมยอดทั้งหมดของออเดอร์ที่ตรงกับ uid
$sql = "SELECT SUM(total_amount) AS grand_total 
        FROM order_book 
        INNER JOIN book ON order_book.bid = book.bid 
        WHERE order_book.uid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $uid);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$grand_total = $row['grand_total'] ?? 0; // ถ้าไม่มีค่า ให้เป็น 0
?>

<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>แจ้งการชำระเงิน</title>

<!-- Bootstrap 5 CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Roboto', sans-serif;
    background: linear-gradient(135deg, #f0f4ff 0%, #d9e8ff 100%);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
  }

  .payment-form-card {
    background-color: #fff;
    padding: 30px 25px;
    border-radius: 20px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 500px;
    transition: transform 0.3s, box-shadow 0.3s;
  }

  .payment-form-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
  }

  .payment-form-card h3 {
    text-align: center;
    font-weight: 700;
    color: #343a40;
    margin-bottom: 20px;
  }

  .form-label {
    font-weight: 500;
    color: #495057;
  }

  .form-control {
    border-radius: 12px;
    padding: 10px 15px;
  }

  .btn-submit {
    width: 100%;
    font-size: 1.1rem;
    padding: 12px;
    border-radius: 12px;
    font-weight: 500;
    transition: all 0.3s;
  }

  .btn-submit:hover {
    background-color: #0b5ed7;
    border-color: #0b5ed7;
  }
</style>
</head>
<body>

<div class="payment-form-card">
  <h3>📤 แจ้งการชำระเงิน</h3>
  
  <form action="save_pay.php" method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">ยอดเงิน (บาท)</label>
      <input type="number" step="0.01" name="amount" class="form-control" 
             value="<?php echo number_format($grand_total, 2, '.', ''); ?>" readonly required>
    </div>

    <div class="mb-3">
      <label class="form-label">ธนาคารที่โอน</label>
      <select name="method" class="form-control" required>
        <option value="กรุงไทย">กรุงไทย</option>
        <option value="SCB">SCB</option>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">วันที่/เวลาโอน</label>
      <input type="datetime-local" name="transfer_date" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label">อัปโหลดรูปสลิป (jpg/png/pdf)</label>
      <input type="file" name="slip" accept=".jpg,.jpeg,.png,.pdf" class="form-control" required>
    </div>

    <input type="hidden" name="uid" value="<?php echo $uid; ?>">

    <button class="btn btn-primary btn-submit" type="submit">ส่งแจ้งชำระ</button>
  </form>
</div>

</body>
</html>
