<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: ../../LoginAndRegister/Login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ยืนยันการลบบัญชี</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            max-width: 400px;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="card bg-white">
        <h4 class="text-danger text-center mb-4">ยืนยันการลบบัญชี</h4>
        <form method="POST" action="delete_account.php">
            <div class="mb-3">
                <label for="password" class="form-label">กรอกรหัสผ่านเพื่อยืนยัน</label>
                <input type="password" class="form-control" name="password" id="password" required>
            </div>
            <button type="submit" class="btn btn-danger w-100">ลบบัญชีถาวร</button>
            <a href="userprofile.php" class="btn btn-secondary w-100 mt-2">ยกเลิก</a>
        </form>
    </div>
</body>
</html>
