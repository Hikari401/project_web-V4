<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบสิทธิ์ admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "คุณไม่มีสิทธิ์เข้าถึงหน้านี้";
    exit();
}

// เลือกฐานข้อมูล bookshop
$dbname = "bookshop";
if (!$conn->select_db($dbname)) {
    die("Error selecting database: " . $conn->error);
}

// ดึงข้อมูลผู้ใช้ทั้งหมด
$sql = "SELECT * FROM user ORDER BY uid";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>จัดการผู้ใช้</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f4;
            margin: 40px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            margin: auto;
            border-collapse: collapse;
            width: 90%;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            border: 1px solid #ccc;
            padding: 12px 15px;
            text-align: center;
        }
        table th {
            background-color: #007acc;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            text-decoration: none;
            color: #007acc;
            font-weight: bold;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
        .btn {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
            color: white;
        }
        .btn-edit { background-color: #28a745; }
        .btn-delete { background-color: #dc3545; }
    </style>
</head>
<body>

<h2>รายชื่อผู้ใช้ทั้งหมด</h2>

<div style="text-align: center; margin-bottom: 20px;">
    <a href="adduserform.php" class="btn btn-edit">+ เพิ่มผู้ใช้</a>
</div>

<?php
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr>
            <th>รหัสผู้ใช้</th>
            <th>ชื่อ</th>
            <th>นามสกุล</th>
            <th>Username</th>
            <th>Email</th>
            <th>เบอร์โทร</th>
            <th>บทบาท</th>
            <th>ที่อยู่</th>
            <th>วันที่สร้าง</th>
            <th>แก้ไข</th>
            <th>ลบ</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["uid"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["surname"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["username"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["tel"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["role"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["address"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["created_at"]) . "</td>";

        echo "<td><a href='edituserform.php?uid=" . urlencode($row["uid"]) . "' class='btn btn-edit'>แก้ไข</a></td>";
        echo "<td><a href='deleteuser.php?uid=" . urlencode($row["uid"]) . "' class='btn btn-delete' onclick=\"return confirm('คุณต้องการลบผู้ใช้นี้หรือไม่?');\">ลบ</a></td>";

        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<p style='text-align:center; color:red;'>ยังไม่มีผู้ใช้</p>";
}
?>

<div class="back-link">
    <a href="../admin-page.php">[ ย้อนกลับ ]</a>
</div>

</body>
</html>
