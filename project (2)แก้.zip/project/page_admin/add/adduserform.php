<?php
session_start();
require_once __DIR__ . '/../../condb.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "คุณไม่มีสิทธิ์เข้าถึงหน้านี้";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $tel = $_POST['tel'];
    $role = $_POST['role'];
    $address = $_POST['address'];

    $sql = "INSERT INTO user (name, surname, username, password, email, tel, role, address) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $name, $surname, $username, $password, $email, $tel, $role, $address);

    if ($stmt->execute()) {
        echo "<script>alert('เพิ่มผู้ใช้สำเร็จ');window.location.href='user_list.php';</script>";
    } else {
        echo "<script>alert('เกิดข้อผิดพลาด: ".$conn->error."');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<title>เพิ่มผู้ใช้</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4">เพิ่มผู้ใช้ใหม่</h2>
    <form method="POST">
        <div class="mb-3">
            <label>ชื่อ</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>นามสกุล</label>
            <input type="text" name="surname" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label>เบอร์โทร</label>
            <input type="text" name="tel" class="form-control">
        </div>
        <div class="mb-3">
            <label>บทบาท</label>
            <select name="role" class="form-control" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
        </div>
        <div class="mb-3">
            <label>ที่อยู่</label>
            <textarea name="address" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-success">เพิ่มผู้ใช้</button>
        <a href="userform.php" class="btn btn-secondary">ย้อนกลับ</a>
    </form>
</div>
</body>
</html>
