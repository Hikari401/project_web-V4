<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่ามีการล็อกอิน admin หรือไม่
if (!isset($_SESSION['username'])) {
    echo "No admin is logged in.";
    exit();
}

// เลือกฐานข้อมูล bookshop
$dbname = "bookshop";
if (!$conn->select_db($dbname)) {
    echo "<div class='status error'>Error selecting database: " . $conn->error . "</div>";
}

// ดึงข้อมูลหนังสือทั้งหมด
$sql = "SELECT * FROM book ORDER BY bid";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>แสดงรายชื่อหนังสือ</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f4f4f4;
            margin: 40px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            margin: auto;
            border-collapse: collapse;
            width: 90%;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table th, table td {
            border: 1px solid #ccc;
            padding: 12px 15px;
            text-align: center;
        }
        table th {
            background-color: #007acc;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            text-decoration: none;
            color: #007acc;
            font-weight: bold;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
        img.book-img {
            max-width: 80px;
            max-height: 100px;
            object-fit: contain;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h2>รายชื่อหนังสือทั้งหมด</h2>

<div style="text-align: center; margin-bottom: 20px;">
    <a href="addform.php" style="
        display: inline-block;
        background-color: #28a745;
        color: white;
        padding: 10px 20px;
        text-decoration: none;
        border-radius: 5px;
        font-weight: bold;
    ">+ เพิ่มหนังสือ</a>
</div>

<?php
if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr>
        <th>รหัสหนังสือ</th>
        <th>ภาพ</th>
        <th>ชื่อหนังสือ</th>
        <th>ผู้แต่ง</th>
        <th>ราคา (บาท)</th>
        <th>สำนักพิมพ์</th>
        <th>หมวดหมู่</th>
        <th>รายละเอียด</th>
        <th>จำนวนคงเหลือ</th>
        <th>แก้ไข</th>
        <th>ลบ</th>
    </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row["bid"]) . "</td>";
        echo "<td><img src='" . htmlspecialchars($row["image"]) . "' alt='Book Image' class='book-img'></td>";
        echo "<td>" . htmlspecialchars($row["title"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["author"]) . "</td>";
        echo "<td>" . number_format($row["price"], 2) . "</td>";
        echo "<td>" . htmlspecialchars($row["publisher"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["category"]) . "</td>";
        echo "<td>" . htmlspecialchars($row["details"]) . "</td>";
        echo "<td>" . intval($row["stock"]) . "</td>";

        echo "<td><a href='editbookform.php?bid=" . urlencode($row["bid"]) . "'>[แก้ไข]</a></td>";
        echo "<td><a href='deletebook.php?bid=" . urlencode($row["bid"]) . "' onclick=\"return confirm('คุณต้องการลบหนังสือเรื่องนี้หรือไม่?');\">[ลบ]</a></td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "<div class='status error'>ไม่มีข้อมูลหนังสือ</div>";
}
?>

<div class="back-link">
    <a href="../admin-page.php">[ ย้อนกลับ ]</a>
</div>

</body>
</html>
