<?php
session_start();
require_once __DIR__ . '/../../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $bid = $_POST['bid'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $price = $_POST['price'];
    $publisher = $_POST['publisher'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];
    $details = $_POST['details'] ?? ''; // เพิ่ม details
    $image_url = $_POST['image_url'] ?? '';

    // ดึงข้อมูลหนังสือเดิม
    $stmt = $conn->prepare("SELECT image FROM book WHERE bid = ?");
    $stmt->bind_param("i", $bid);
    $stmt->execute();
    $result = $stmt->get_result();
    $book = $result->fetch_assoc();

    $currentImage = $book['image']; // เก็บภาพเดิม

    // ตรวจสอบว่ามีการอัปโหลดไฟล์ใหม่หรือไม่
    if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/uploads/'; // โฟลเดอร์เก็บไฟล์
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $tmpName = $_FILES['image_file']['tmp_name'];
        $ext = pathinfo($_FILES['image_file']['name'], PATHINFO_EXTENSION);
        $newFileName = uniqid() . '.' . $ext;
        $destination = $uploadDir . $newFileName;

        if (move_uploaded_file($tmpName, $destination)) {
            // ลบไฟล์เก่า (ถ้าเป็นไฟล์อัปโหลด ไม่ใช่ URL)
            if ($currentImage && !filter_var($currentImage, FILTER_VALIDATE_URL)) {
                $oldPath = __DIR__ . '/' . $currentImage;
                if (file_exists($oldPath)) {
                    unlink($oldPath);
                }
            }
            $finalImage = 'uploads/' . $newFileName; // path ใหม่เก็บใน DB
        } else {
            $finalImage = $currentImage; // ถ้าอัปโหลดล้มเหลว ใช้เดิม
        }
    } else {
        // ไม่มีการอัปโหลดใหม่
        if (!empty($image_url)) {
            $finalImage = $image_url; // ใช้ URL
        } else {
            $finalImage = $currentImage; // ใช้ไฟล์เดิม
        }
    }

    // อัปเดตข้อมูลหนังสือ พร้อม details
    $stmt = $conn->prepare("UPDATE book SET title=?, author=?, price=?, publisher=?, category=?, stock=?, details=?, image=? WHERE bid=?");
    $stmt->bind_param("ssississi", $title, $author, $price, $publisher, $category, $stock, $details, $finalImage, $bid);

    if ($stmt->execute()) {
        echo "<script>alert('แก้ไขหนังสือเรียบร้อยแล้ว'); window.location.href='bookform.php';</script>";
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }
}
?>
