<?php
session_start();
require_once __DIR__ . '/../condb.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

// ตรวจสอบสิทธิ์ Admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "คุณไม่มีสิทธิ์เข้าถึงหน้านี้";
    exit();
}

// เลือกฐานข้อมูล
$dbname = "bookshop";
if (!$conn->select_db($dbname)) {
    die("Error selecting database: " . $conn->error);
}

// ===== อัปเดตสถานะ: ส่งของแล้ว =====
if (isset($_GET['order_number'])) {
    $order_number = $_GET['order_number'];

    // อัปเดตสถานะทุกแถวที่มี order_number นี้
    $updateSql = "UPDATE order_details SET status = 'Item has been shipped.' WHERE order_number = ?";
    $stmtUpdate = $conn->prepare($updateSql);
    $stmtUpdate->bind_param("s", $order_number);
    $stmtUpdate->execute();

    // ป้องกันการกดรีเฟรชแล้วยิงซ้ำ
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// ===== ดึงประวัติการสั่งซื้อทั้งหมด (รวมรายการใน order เดียวกัน) =====
// ใช้ GROUP_CONCAT เพื่อรวมชื่อหนังสือและผู้แต่ง
// SUM เพื่อรวมจำนวนและราคาทั้งหมดใน order นั้น
// MAX(status) และ MIN(status) เพื่อช่วยดูสถานะรวมของ order

$sql = "
SELECT 
    od.order_number,
    u.name, u.surname, u.address,
    GROUP_CONCAT(CONCAT(b.title, ' (', b.author, ')') SEPARATOR '<br>') AS books,
    SUM(od.quantity) AS total_quantity,
    SUM(od.quantity * od.price) AS total_price,
    -- ตรวจสอบสถานะ order ทั้งหมด
    -- ถ้าใน order มี 'pending' หรือ 'confirmed' ให้แสดงสถานะ 'confirmed'
    -- ถ้าทุก item เป็น 'Item has been shipped.' แสดงสถานะนี้
    CASE 
        WHEN SUM(od.status = 'Item has been shipped.') = COUNT(*) THEN 'Item has been shipped.'
        WHEN SUM(od.status = 'confirmed') > 0 THEN 'confirmed'
        ELSE 'pending'
    END AS status,
    MAX(od.order_date) AS order_date
FROM order_details od
INNER JOIN book b ON od.bid = b.bid
INNER JOIN user u ON od.uid = u.uid
WHERE od.status IN ('pending', 'confirmed', 'Item has been shipped.')
GROUP BY od.order_number, u.name, u.surname, u.address
ORDER BY order_date DESC, order_number DESC
";

$result = $conn->query($sql);

// helper: แปลงสถานะเป็น badge สี
function renderStatusBadge($status) {
    $map = [
        'pending'                 => 'warning',
        'confirmed'               => 'success',
        'rejected'                => 'danger',
        'Item has been shipped.'  => 'primary',
    ];
    $cls = $map[$status] ?? 'secondary';
    return '<span class="badge bg-'.$cls.'">'.htmlspecialchars($status).'</span>';
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>ประวัติการสั่งซื้อ - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f4f4; margin: 20px; }
        table th, table td { text-align: center; vertical-align: middle; }
        table thead th { background-color: #007acc; color: white; }
        td.text-start { text-align: left; }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">รายละเอียดการสั่งซื้อของผู้ใช้</h2>

    <?php if ($result && $result->num_rows > 0): ?>
        <div class="table-responsive">
        <table class="table table-bordered shadow-sm bg-white align-middle">
            <thead>
                <tr>
                    <th>หมายเลขคำสั่งซื้อ (Order Number)</th>
                    <th>ชื่อผู้ซื้อ</th>
                    <th>ที่อยู่ผู้ซื้อ</th>
                    <th>หนังสือ (ชื่อเรื่อง + ผู้แต่ง)</th>
                    <th>จำนวนรวม</th>
                    <th>ราคารวม (บาท)</th>
                    <th>สถานะ</th>
                    <th>วันที่สั่งซื้อ</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()):
                    $totalQty = (int)$row['total_quantity'];
                    $totalPrice = (float)$row['total_price'];
                ?>
                    <tr>
                        <td><?= htmlspecialchars($row['order_number']) ?></td>
                        <td class="text-start"><?= htmlspecialchars($row['name'].' '.$row['surname']) ?></td>
                        <td class="text-start"><?= htmlspecialchars($row['address']) ?></td>
                        <td class="text-start"><?= $row['books'] ?></td>
                        <td><?= $totalQty ?></td>
                        <td class="fw-semibold text-danger"><?= number_format($totalPrice, 2) ?></td>
                        <td><?= renderStatusBadge($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['order_date']) ?></td>
                        <td>
                            <?php if ($row['status'] !== 'Item has been shipped.'): ?>
                                <a href="?order_number=<?= urlencode($row['order_number']) ?>" class="btn btn-success btn-sm"
                                   onclick="return confirm('ยืนยันว่าส่งของแล้ว?')">ส่งของแล้ว</a>
                            <?php else: ?>
                                <span class="text-muted">ส่งแล้ว</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    <?php else: ?>
        <p class="text-center text-danger">ยังไม่มีรายละเอียดการสั่งซื้อ</p>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="admin-page.php" class="btn btn-primary">กลับไปหน้าหลัก</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
