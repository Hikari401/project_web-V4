<?php
include "condb2.php";

$dbname = "bookshop";

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS bookshop";
if ($conn->query($sql) === TRUE) {
  echo "Database created successfully<br>";
} else {
  echo "Error creating database: " . $conn->error;
}

//select database
if($conn->select_db($dbname)){
  echo "Database $dbname selected successfully!<br>";
} else {
  echo "Error selecting database: ".$conn->error;
}

// Create table User
$sql_u = "CREATE TABLE IF NOT EXISTS user (
    uid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(30),
    surname VARCHAR(30),
    username VARCHAR(30) UNIQUE,
    password VARCHAR(255),
    email VARCHAR(30),
    tel VARCHAR(10),
    role VARCHAR(10),
    address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql_u) === TRUE) {
  echo "Table User created successfully<br>";
} else {
  echo "Error creating table User: " . $conn->error;
}

// Add Admin
$admin_username = 'admin';
$admin_password = '1234';
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

$check_admin = "SELECT * FROM user WHERE username = 'admin'";
$result = $conn->query($check_admin);
if ($result->num_rows === 0) {
    $sql_insert_admin = "INSERT INTO user (username, password, role) 
                         VALUES ('$admin_username', '$hashed_password', 'admin')";
    if ($conn->query($sql_insert_admin) === TRUE) {
        echo "Admin user created successfully<br>";
    } else {
        echo "Error: " . $sql_insert_admin . "<br>" . $conn->error;
    }
}

// Create table Book
$sql_book = "CREATE TABLE IF NOT EXISTS book(
    bid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    author VARCHAR(30),
    price INT(10) NOT NULL,
    publisher VARCHAR(30),
    category VARCHAR(50),
    details VARCHAR(500),
    stock INT(10) NOT NULL,
    image VARCHAR(255)
)";
if ($conn->query($sql_book) === TRUE) {
  echo "Table Book created successfully<br>";
} else {
  echo "Error creating table Book: " . $conn->error;
}

// Add sample books (เฉพาะตอนยังไม่มีหนังสือ)
$check_books = $conn->query("SELECT COUNT(*) as total FROM book");
$row_books = $check_books->fetch_assoc();
if ($row_books['total'] == 0) {
    $sql_add_book = "INSERT INTO book (title, author, price, publisher, category, details, stock, image)
    VALUES
    ('PHP เบื้องต้น', 'สมชาย เขียนดี', 199, 'TechPress', 'Programming', 'หนังสือสอน PHP สำหรับผู้เริ่มต้น', 10, 'https://picsum.photos/200/300?random=1'),
    ('เรียนรู้ MySQL', 'สมหญิง DBA', 180, 'DataHouse', 'Database', 'คู่มือเรียนรู้ MySQL ตั้งแต่พื้นฐาน', 15, 'https://picsum.photos/200/300?random=2'),
    ('Java ฉบับพื้นฐาน', 'อนันต์ โค้ดมันส์', 220, 'CodeBook', 'Programming', 'แนะนำ Java สำหรับผู้เริ่มต้น', 8, 'https://picsum.photos/200/300?random=3'),
    ('การตลาดดิจิทัล', 'ณัฐกานต์ โปรโมท', 250, 'BizMedia', 'Business', 'แนวทางการตลาดดิจิทัลสำหรับธุรกิจ', 20, 'https://picsum.photos/200/300?random=4')";
    
    if ($conn->query($sql_add_book) === TRUE) {
        echo "Sample books inserted successfully<br>";
    } else {
        echo "Error inserting sample books: " . $conn->error;
    }
}


// Create table Order
$sql_order = "CREATE TABLE IF NOT EXISTS order_book (
    oid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid INT(10) UNSIGNED,
    bid INT(10) UNSIGNED,
    order_date DATE DEFAULT (CURRENT_DATE),
    quantity INT NOT NULL DEFAULT 1,
    total_amount INT(10),
    FOREIGN KEY (uid) REFERENCES user(uid) ON DELETE CASCADE,
    FOREIGN KEY (bid) REFERENCES book(bid) ON DELETE CASCADE
)";
if ($conn->query($sql_order) === TRUE) {
  echo "Table Order created successfully<br>";
} else {
  echo "Error creating table Order: " . $conn->error;
}

// Create table Payment
$sql_pay = "CREATE TABLE IF NOT EXISTS payment (
    pid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid INT(10) UNSIGNED,
    oid INT(10) UNSIGNED UNIQUE,
    amount DECIMAL(10,2),
    method VARCHAR(50), 
    slip VARCHAR(255), 
    order_number VARCHAR(10),
    status ENUM('pending','confirmed','rejected','Item has been shipped.') DEFAULT 'pending',
    pay_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (uid) REFERENCES user(uid) ON DELETE CASCADE,
    FOREIGN KEY (oid) REFERENCES order_book(oid) ON DELETE SET NULL
)";
if ($conn->query($sql_pay) === TRUE) {
  echo "Table Payment created successfully<br>";
} else {
  echo "Error creating table Payment: " . $conn->error;
}

// Create table Order_Details
$sql_order_details = "CREATE TABLE IF NOT EXISTS order_details (
    odid INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uid INT(10) UNSIGNED ,
    bid INT(10) UNSIGNED NOT NULL,
    oid INT(10) UNSIGNED,
    order_number VARCHAR(10),
    quantity INT(10) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    order_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('pending','confirmed','rejected','Item has been shipped.') DEFAULT 'pending',
    FOREIGN KEY (uid) REFERENCES user(uid) ON DELETE CASCADE,
    FOREIGN KEY (bid) REFERENCES book(bid) ON DELETE CASCADE,
    FOREIGN KEY (oid) REFERENCES order_book(oid) ON DELETE SET NULL
)";
if ($conn->query($sql_order_details) === TRUE) {
    echo "Table Order_Details created successfully<br>";
} else {
    echo "Error creating table Order_Details: " . $conn->error;
}

$sql_reviews = "CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    bid INT UNSIGNED,              
    uid INT UNSIGNED,              
    rating INT NOT NULL,           
    comment TEXT,                  
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bid) REFERENCES book(bid) ON DELETE CASCADE,
    FOREIGN KEY (uid) REFERENCES user(uid) ON DELETE CASCADE
)";
if ($conn->query($sql_reviews) === TRUE) {
    echo "Table Order_Details created successfully<br>";
} else {
    echo "Error creating table Order_Details: " . $conn->error;
}

// redirect ไปหน้า main/h.php
echo "<script>window.location.href='main/h.php';</script>";
?>
