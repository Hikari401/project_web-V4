<?php
require_once __DIR__ . '/../condb.php'; // เชื่อมต่อฐานข้อมูล
session_start();

$username = $_SESSION['username'];
$password = $_SESSION['password'];

$conn->select_db("bookshop");

// Prepare and bind
$stmt = $conn->prepare("SELECT * FROM user WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['username'] = $user['username'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'admin') {
            header("Location: ../page_admin/admin-page.php");
            exit();
        } else {
            header("Location: ../page_user/user-page.php");
            exit();
        }
    } else {
        // Password ไม่ถูกต้อง
        header("Location: Login.php?error=รหัสผ่านไม่ถูกต้อง");
        exit();
    }
} else {
    // ไม่พบ username
    header("Location: Login.php?error=ไม่พบผู้ใช้งาน");
    exit();
}
?>
